#' Tooltips
#' 
#' This is to implement tooltips as explanatory fiels of inputs

add_text <- "<p><b> If this checkbox is selected, the standard settings are used. If you decide to unselect this checkbox,
you are able to select e.g. date interval on your own.</b></p>
<p> Possible settings you are able to select manually: </p>
<p><li> Dates (Standard: Date interval of mediaplan and one month in advance)</li>"

addPopover(session, id = 'add_settings', title = 'Standard Settings', content = add_text)