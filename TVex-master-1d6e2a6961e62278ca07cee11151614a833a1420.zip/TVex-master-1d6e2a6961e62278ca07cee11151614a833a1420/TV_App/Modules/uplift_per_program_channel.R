#' Program Anlysis
#' 
#' Three Uplift analysis for programs are available
#' 1. Top Programs: sum uplift per program. Select channel possible
#' 2. Barplots: Average uplift per program. Channel selection
#' 3. Extreme Programs: Sum uplift per program. Show only upper and lower (5%-)quantile 
#' of programs. Select channel possible
#' 
#' Output in powerpoint is always seperated by channel. 
#' 


# Channel Spots 
data_uplift2 = react_uplift_calculation()
channel_spots = data_uplift2[, .(sum_spots = length(Program)),  by = .(Channel)]
setorderv(channel_spots, "sum_spots", order = -1)

# 1. Top 20 TV shows per uplift in events -------------------------------
react_top_programs <- reactive({
  
  data_uplift2 = react_uplift_calculation()
  
  # Calculate the sum of uplift per program per channel
  top_20_Program = data_uplift2[,.( 
    sum_uplift = mean(uplift_events_ma, na.rm = TRUE), 
    numb_spots = length(uplift_events)
  ),  by=.(Program, Channel)]
  top_20_Program = arrange(top_20_Program, desc(sum_uplift))
  top_20_Program = data.table(top_20_Program)
  
  unique_channels = c("All", unique(top_20_Program$Channel))
  
  # Loop over unique channels
  uplift_program_per_channel <- lapply(unique_channels, function(channel){
    
    if(channel == "All"){
      return(top_20_Program)
    } else {
      return(top_20_Program[channel, on = .(Channel)])
    }
    
  })
  names(uplift_program_per_channel) = unique_channels
  return(uplift_program_per_channel)
  
})

# Render table of top programs
output$top20 = renderDataTable({
  
  datatable(react_top_programs()[[input$select_channel_topProgram]]) %>%
    formatRound("sum_uplift", digits = 3)
  
})


# 2. barchart for average uplift of programs -----------------
react_barchart_uplift_data <- reactive({
  
  data_uplift2 = react_uplift_calculation()
  unique_channels = unique(data_uplift2$Channel)
  
  # run loop over all channels
  plots_barplot_uplift = lapply(unique_channels, function(channel){
    
    # Calculate average uplift per program per channel 
    barplot_data <- data_uplift2[Channel == channel, .(
      avg_uplift = mean(uplift_events_ma, na.rm = TRUE)
    ), by = .(Program, Channel)]
    barplot_data <- barplot_data[!is.na(avg_uplift)]
    setorder(barplot_data, -avg_uplift)
    
    # select maximum of of top 7 programs
    nr_programs <- ifelse(nrow(barplot_data) >= 7, 7, nrow(barplot_data))
    barplot_data <- barplot_data[1:nr_programs]
    
    # set up x axis labels. get linebreaks into labels by seperating the labels by spaces and 
    # fill them back together by every 12 char but with a linebreak 
    x_labels = barplot_data$Program
    label_list = stri_split_fixed(x_labels, " ")
    if(!all(is.na(x_labels))){
      x_axis_labels = unlist(lapply(label_list, function(element){
        # unlist elements
        element = unlist(element)
        
        # if more than one : or - is included then split at that point and take only the first part as a label
        if(length(grep(":", element)) >= 1 | length(grep("-", element)) >= 1){
          idx <- sort(c(grep(":", element), grep("-", element)))
          return(paste0(gsub("-", "", gsub(":", "", element[1:idx[1]])), collapse = " "))
        }
        
        # else split labels every 12 element
        max_num = 12
        nr_chars = cumsum(nchar(element) + 1)
        
        # quit if label is shorter than 12 chars
        if(max(nr_chars) < max_num){
          return(paste0(element, collapse = " "))
        }
        
        # take sequence every 12 element
        sep_nrs = seq(max_num, max(nr_chars), max_num)
        new_string = ""
        # loop through elements in sequence
        for(nr in sep_nrs){
          # if all number of chars per word are above 12 then new_string is added with words 
          # until first element above selected number
          if(all(nr_chars > nr)){
            new_string = paste0(new_string, element[1])
            element = element[-1]
            nr_chars = nr_chars[-1]
          } else {
            # edit elements with smaller number of elements and delete used ones
            new_string = paste0(new_string, paste0(element[nr_chars <= nr], collapse = " "), "\n")
            element = element[-which(nr_chars <= nr)]
            nr_chars = nr_chars[-which(nr_chars <= nr)]
          }
          
        }
        
        # If there are still some words left, just simply add them
        if(length(nr_chars) > 0){
          new_string = paste0(new_string, paste0(element, collapse = " "))
        }
        return(new_string)
      }))
    } else {
      x_axis_labels <- x_labels
    }
    
    # If there are duplicated spots, then add number at the end
    if(any(duplicated(x_axis_labels))){
      dup <- x_axis_labels[duplicated(x_axis_labels)]
      for(lab in dup){
        idx <- grep(lab, x_axis_labels)
        x_axis_labels[idx] <- paste(lab, 1:length(idx))
      }
    }
    
    
    # visualise plots
    ggplot(data = barplot_data, aes(x = reorder(Program, -avg_uplift), y = avg_uplift)) + 
      geom_bar(stat = "identity", fill = "#F78B2C") + 
      scale_x_discrete(
        breaks = barplot_data$Program,
        labels = x_axis_labels
      ) +
      labs(y = "Uplift Events", x = "") +
      theme_criteo_default(base_size = 2) +
      theme(
        legend.position = "none",
        axis.text.x = element_text(
          size = 14, angle = 25, hjust = 1
        )
      ) 
    
  })
  names(plots_barplot_uplift) = unique_channels
  
  return(plots_barplot_uplift)
  
})

# Render bar charts
output$uplift_programs_barplot <- renderPlot({
  
  react_barchart_uplift_data()[[input$select_channel_barplotUplift]]
  
})


# 3. extreme programs ------------
# setup column for uplift by moving average selection
react_uplift_col <- reactive({
  
  # use moving average for uplift calc
  if(input$moving_average){
    y_uplift <- paste0(input$selectUplift, "_ma")
  } else {
    y_uplift <- input$selectUplift
  }
  
  return(y_uplift)
  
})

# Extreme performing programs uplift. 
react_table_extreme_uplift <- reactive({
  
  data_uplift2 <- react_uplift_calculation()
  uplift_col <- react_uplift_col()
  
  unique_channels = c("All", channel_spots$Channel)
  
  # Set up tables by channel
  extreme_uplift <- lapply(unique_channels, function(channel){
    
    # Filter by channel or use all
    if(channel != "All"){
      uplift_data <- data_uplift2[channel, on = .(Channel)]
    } else {
      uplift_data <- data_uplift2
    }
    
    # Calculate quantile to select number of spot in that quantile, only use upper so top programs
    extreme_quant <- quantile(uplift_data[[uplift_col]], 
                              probs = 1 - (input$quantile_extreme_uplift / 100), 
                              na.rm = TRUE)
    extreme_uplift <- uplift_data[uplift_data[[uplift_col]] >= extreme_quant]
    setorder(extreme_uplift, uplift_events)
    
    return(extreme_uplift)
    
  })
  names(extreme_uplift) = unique_channels
  
  return(extreme_uplift)
  
})


# Render table with extreme uplifts
output$extreme_uplift_overview <- renderDataTable({
  
  extreme_uplift <- react_table_extreme_uplift()[[input$select_channel_extremeProgram]]
  uplift_col <- react_uplift_col()
  datatable(
    extreme_uplift[, c("Date", "dayofweek", "Time", "Channel", "Program", uplift_col), with = FALSE], 
    rownames = FALSE, class = "display"
  ) %>%
    formatRound(uplift_col, digits = 3)
  
})

