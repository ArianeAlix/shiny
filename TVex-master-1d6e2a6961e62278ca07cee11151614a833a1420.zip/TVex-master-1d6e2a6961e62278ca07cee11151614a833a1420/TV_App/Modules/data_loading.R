#' Data loading and preperation for Hive and mediaplan data
#' 
#' This includes multiple steps: 
#'     1. Read TV Plan: This is differentiated by selected tracking provider
#'         1.1 Mediaplan xlsx: REad in and mainly change time columns
#'         1.2 Spotwatch csv: formatting and adjusting time by timezone
#'         1.3 TVTY tracking: Extract data from hive (or load) and format columns
#'     2. Adjustment of weekday and program columns
#'     3. Extract Event data from hive: 
#'         3.1. Write and adjust query to date range, number of splits per hour and 
#'              partner id. 
#'         3.2 Extract data (needs around 20 min)
#'     4. Formatting Hive: Format extract hive data reatively: 
#'         - general formatting, date range and other stuff
#'         - aggragate over selected nr of splits
#'     5. Final prep of mediaplan: Adjust to selected number of splits per hour
#' 
#' @param input reactive inputs by shiny
#' @param output reactive output by app
#' @return list with mediaplan, hive_data and the date_range to be used. 
#' @author Conrad Quandel <c.quandel@@criteo.com>
#' @export
#' 


# 1. Read TV Plan --------------------
if(input$tracking_provider == 'mediaplan'){
  
  # 1.1 Mediaplan Input -------------------------------
  input_mediaplan <- openxlsx::read.xlsx(input$mediaplan$datapath, sheet = 1)
  
  # Setting time format
  if(all(is.na(as.numeric(input_mediaplan$Time)))){
    input_mediaplan$Time <- factor(input_mediaplan$Time)
  } else {
    input_mediaplan$Time <- as.POSIXct(as.numeric(input_mediaplan$Time) * 24 * 60 * 60, origin = "1899-12-30", tz = "UTC")
  }
  
  # If times need to be transformed from irregular hour and minute informations
  if(any(is.na(strptime(input_mediaplan$Time, format = "%H:%M"))) & !all(is.na(strptime(input_mediaplan$Time, format = "%H:%M")))){
    
    input_mediaplan <- transform_times(input_mediaplan = input_mediaplan, 
                                       time_col = "Time")
    input_mediaplan$Time <- factor(input_mediaplan$Time)
    
  }
  
  # drop unused levels
  input_mediaplan <- droplevels(input_mediaplan)
  
  # Set Date, time, Timestamp and Hour information
  if('Date' %in% colnames(input_mediaplan)){
    input_mediaplan$Date <- as.Date(input_mediaplan$Date, origin = '1899-12-30')
  } else {
    input_mediaplan$Date <- as.Date(input_mediaplan$Time)
  }
  input_mediaplan$Time <- as.POSIXct(as.character(input_mediaplan$Time))
  input_mediaplan$Time <- format(input_mediaplan$Time, "%H:%M:%S")
  input_mediaplan$timestamp <- paste(input_mediaplan$Date, input_mediaplan$Time, sep=" ")
  input_mediaplan$timestamp <- as.POSIXct(strptime(input_mediaplan$timestamp, "%Y-%m-%d %H:%M:%S"))
  input_mediaplan$Hour <- as.integer(format(input_mediaplan$timestamp, format = '%H'))
  
} else if (input$tracking_provider == 'spotwatch'){
  
  # 1.2 Spotwatch tracking ----------------------------
  input_mediaplan <- read.csv2(input$spotwatch$datapath, encoding = 'UTF-8', stringsAsFactors = FALSE)
  
  # Calculate difference in utc and selected timezone. 
  timezone_diff <- difftime(format(Sys.time(), tz = input$timezone_spotwatch), format(Sys.time(), tz = "UTC"), units = "hour")
  
  # Adjust Date, Time, Hour, Timestamp, particularly for timezone_diff to utc time
  input_mediaplan$Date <- as.Date(input_mediaplan$time)
  input_mediaplan$Time <- as.POSIXct(as.character(input_mediaplan$time))
  input_mediaplan$Time <- input_mediaplan$Time + timezone_diff
  input_mediaplan$Time <- format(input_mediaplan$Time, "%H:%M:%S")
  input_mediaplan$timestamp <- paste(input_mediaplan$Date, input_mediaplan$Time, sep=" ")
  input_mediaplan$timestamp <- as.POSIXct(strptime(input_mediaplan$timestamp, "%Y-%m-%d %H:%M:%S"))
  input_mediaplan$Hour <- as.integer(format(input_mediaplan$timestamp, format = '%H'))
  
  input_mediaplan <- plyr::rename(input_mediaplan, c("channel" = "Channel"))
  
  input_mediaplan <- droplevels(input_mediaplan)
  
  
} else if (input$tracking_provider == 'tvty'){
  
  # 1.3 TVTY tracking ---------------------------------
  # Load already existing mediaplan or extract hive data 
  if(length(input$tvty_mediaplan_rows_selected) == 0){
    
    withProgress(message = 'Extracting TVTY Mediaplan Data from Vertica', value = 0, {
    
      # Adjust tvty query 
      # tvty_query <- readr::read_file("./Modules/TVTY_Data/tvty_data.sql")
      # tvty_query <- gsub("__start_date__", paste0("'", input$tvty_daterange[1], "'"), tvty_query)
      # tvty_query <- gsub("__end_date__", paste0("'", input$tvty_daterange[2], "'"), tvty_query)
      # tvty_query <- gsub("__partner_id__", input$partnerID, tvty_query)
      # 
      # # get hive data and write into csv file
      # get_kerberos_token(password = passwd())
      # tvty_data <- pull_data_hive(query = tvty_query,
      #                             username = user(),
      #                             prefix = paste0("hive_temp_", input$partnerID))
      # tvty_data <- unique(tvty_data[, colnames(tvty_data)])
      # write.csv2(tvty_data, file = paste0('Modules/TVTY_Data/loaded_tvty_data_', input$partnerID, '_',
      #                                     paste(input$tvty_daterange, collapse = "_"), '.csv'), 
      #            row.names = FALSE)
      
      # Vertica Data
      tvty_query <- readr::read_file("./Modules/TVTY_Data/tvty_data_vertica.sql")
      tvty_query <- gsub("__start_date__", paste0("'", input$tvty_daterange[1], "'"), tvty_query)
      tvty_query <- gsub("__end_date__", paste0("'", input$tvty_daterange[2], "'"), tvty_query)
      tvty_query <- gsub("__partner_id__", input$partnerID, tvty_query)
      
      tvty_data <- pull_data_vertica(queries = tvty_query, username = user(), 
                                     password = passwd())
      tvty_data <- unique(tvty_data[, colnames(tvty_data)])
      write.csv2(tvty_data, file = paste0('Modules/TVTY_Data/loaded_tvty_data_', input$partnerID, '_',
                                          paste(input$tvty_daterange, collapse = "_"), '.csv'))
      
    })
    
    input_mediaplan <- tvty_data
    
  } else {
    
    # Read already existing file
    file_path <- tvty_media[input$tvty_mediaplan_rows_selected, ]
    input_mediaplan <- read.csv2(paste0('Modules/TVTY_Data/loaded_tvty_data_', file_path, '.csv'), 
                                 stringsAsFactors = FALSE, encoding = "UTF-8")
    
  }
  
  input_mediaplan <- plyr::rename(input_mediaplan, c("tv_channel_name" = "Channel"))
  
  if (is.na(input_mediaplan$partner_id[nrow(input_mediaplan)]) & !is.na(input_mediaplan$timestamp[nrow(input_mediaplan)])){
    input_mediaplan <- input_mediaplan[-c(nrow(input_mediaplan) - 1, nrow(input_mediaplan)), ]
    input_mediaplan$timestamp <- as.integer(input_mediaplan$timestamp)
  }
  
  # Calculate difference in utc and selected timezone. 
  timezone_diff <- difftime(format(Sys.time(), tz = input$timezone_tvty), format(Sys.time(), tz = "UTC"), units = "hour")
  
  # Adjust timestamps, Date, Time, Hour and drop levels
  input_mediaplan$timestamp <- as.POSIXct(input_mediaplan$timestamp, origin="1970-01-01") + timezone_diff
  input_mediaplan$Date <- as.Date(input_mediaplan$timestamp, format = "%d.%m.%Y")
  input_mediaplan$Time <- format(input_mediaplan$timestamp, format = "%H:%M:%S")
  input_mediaplan$Hour <- as.integer(format(input_mediaplan$timestamp, format = '%H'))
  input_mediaplan <- droplevels(input_mediaplan)
  
  # Output header of table in interface
  out_table <- input_mediaplan[, c('timestamp', 'Date', 'Time', 'Hour', 'tv_tracking_provider', 'ad_brand',
                             'country', 'Channel', 'prev_program', 'next_program')]
  output$raw_tvty <- renderDataTable({

    DT::datatable(out_table,
                  selection = list(mode = "single", target = "column"),
                  options = list(lengthMenu = c(5, 10), pageLength = 5))

  })
    
} else {
  stop('No or wrong tracking provider is selected')
}

# 2. General weekday and program adjustments ---------------------
# Additin weekday columns
if(!"weekday" %in% colnames(input_mediaplan)){
  
  input_mediaplan$weekday <- lubridate::wday(input_mediaplan$Date, label = TRUE, abbr = FALSE, 
                                  week_start = 1)
  
}

# Formating program 
if(length(grep("program", colnames(input_mediaplan), ignore.case = TRUE)) > 1){
  
  # If two program columns are in data then merge them into one seperated by '/'
  input_mediaplan[, grep("program", colnames(input_mediaplan), ignore.case = TRUE)] <- 
    input_mediaplan[, grep("program", colnames(input_mediaplan), ignore.case = TRUE)] %>% 
    mutate_if(is.factor, as.character)
  input_mediaplan <- unite(input_mediaplan, col = "Program", colnames(input_mediaplan)[grep("program", colnames(input_mediaplan), ignore.case = TRUE)], 
                           sep = " / ")
  
} else {
  
  colnames(input_mediaplan)[grep("program", colnames(input_mediaplan), ignore.case = TRUE)] <- "Program"
  
}

# 3. Extract event data from Hive ------------------------
# first set the dates, either by manual selection or by tvty date range
if(input$add_settings){
  start_date <- as.Date(min(input_mediaplan$Date)) %m-% months(1)
  end_date <- max(input_mediaplan$Date)
} else {
  start_date <- input$dates_data[1]
  end_date <- input$dates_data[2]
}

# Extract data from hive only if selected
if(input$use_hive){
  
  # 3.1. Edit query --------------------------------
  # smaller time periods for uplift analysis, adjust splits per hour
  no_parts = input$max_splits_per_hour
  
  # this code is writing sql query parts. The hour should be split into a number of 
  # selected parts. This is done for splits from 1 to the selected max splits per hour.
  split_queries = ""
  for(j in 2:no_parts){
    breaks = c(0, seq(60 / j, 60, length.out = j))
    date_part = paste0("case")
    cases = paste0("when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) >= ", breaks[1], 
                   " and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= ", breaks[2], 
                   " then ", 1, "\n")
    for(i in 2:(length(breaks) - 1)){
      cases = paste0(cases, "when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > ", breaks[i], 
                     " and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= ", breaks[i + 1], 
                     " then ", i, "\n")
    }
    if(j == no_parts){
      date_query = paste0(date_part, "\n", cases, "else 0 end as split", j,",")
    } else {
      date_query = paste0(date_part, "\n", cases, "else 0 end as split", j,",\n")
    }
    split_queries = paste(split_queries, date_query)
  }
  
  cols = paste0("split", 2:no_parts, collapse = ", ")
  
 
  # Write sql query for hive 
  # date range and partner id are variables. The rest of the code is fixed
  fileConn <- "./Modules/Hive_data/events_per_hour.sql"
  writeLines(c(paste0("use ", gsub("\\.", "", user()), ";"),
               "set mapreduce.job.name='AXTool_TVex';",
               paste0("SET start_date = \'", start_date, "\';"), 
               paste0("SET end_date = \'", end_date, "\';"), 
               paste0("SET partner_id = ", input$partnerID, ";"), 
               paste0("SET timezone = \'", input$timezone, "\';"), "", 
               
               "SET hive.cli.print.header = FALSE;",
               paste0("DROP TABLE IF EXISTS ", gsub("\\.", "", user()), ".TV_events;"), 
               paste0("create table ", gsub("\\.", "", user()), ".TV_events as"), 
               "select ",
               "to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))as day,", 
               "hour(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string))as Stunde,", 
               ifelse(input$baseline_in_tv_frame, "minute(cast(from_utc_timestamp(from_unixtime(unixtime), ${hiveconf:timezone}) as string)) as Minute, ", ""), 
               "from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as zeitstempel,",
               paste0(split_queries), 
               "unixtime,", 
               "user_id,", 
               "transaction_id,", 
               "referrer,", 
               "event_name,", 
               "previous_url", 
               "from bi_data.partnerdb_bi_advertiser_event", 
               "where to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))>=${hiveconf:start_date} and to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))<=${hiveconf:end_date} and partner_id= ${hiveconf:partner_id} and partner_partition=pmod(${hiveconf:partner_id},1000) and persistent_user=TRUE;",  
               "",
               "SET hive.cli.print.header = FALSE;",
               paste0("DROP TABLE IF EXISTS ", gsub("\\.", "", user()), ".TV_clicks;"), 
               paste0("create table ", gsub("\\.", "", user()), ".TV_clicks as"), 
               "select ", 
               "to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone})) as day,", 
               "hour(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) as Stunde,",
               ifelse(input$baseline_in_tv_frame, "minute(cast(from_utc_timestamp(from_unixtime(unixtime), ${hiveconf:timezone}) as string)) as Minute, ", ""),  
               "from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as zeitstempel,", 
               "unixtime,", 
               "user_id,", 
               "revenue_euro,", 
               "click_cost_euro", 
               "from bi_data.partnerdb_bi_click", 
               "where to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))>=${hiveconf:start_date} and to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))<=${hiveconf:end_date}  and partner_id=${hiveconf:partner_id} and partner_partition=pmod(${hiveconf:partner_id},1000);",  
               "",
               "",
               "SET hive.cli.print.header = TRUE;", 
               "", 
               "Select t1.*, clicks, adv_cost_euro", 
               "from",  
               "(Select",  
               "day,", 
               "Stunde,",
               ifelse(input$baseline_in_tv_frame, "Minute, ", ""), 
               paste0(cols, ","), 
               "min(zeitstempel) as min_zeitstempel,", 
               "max(zeitstempel) as max_zeitstempel,", 
               "count(distinct user_id) as distinct_user_ids,", 
               "count(distinct transaction_id) as transactions,", 
               "count(0) as events", 
               paste0("from ", gsub("\\.", "", user()), ".TV_events"),
               "group by day, Stunde, ", ifelse(input$baseline_in_tv_frame, "Minute, ", ""), cols, ") t1", 
               "left outer join ", 
               "(Select ", 
               "day,", 
               "Stunde,", 
               ifelse(input$baseline_in_tv_frame, "Minute, ", ""),
               "count(0) as clicks,", 
               "sum(revenue_euro) as adv_cost_euro", 
               paste0("from ", gsub("\\.", "", user()), ".TV_clicks"),
               "group by day, Stunde", ifelse(input$baseline_in_tv_frame, ", Minute", ""), 
               ") t2", 
               "on t1.day=t2.day and t1.Stunde=t2.Stunde", ifelse(input$baseline_in_tv_frame, " and t1.Minute=t2.Minute", ""), 
               ";"), 
             con = fileConn)
  
  hive_query <- readr::read_file("./Modules/Hive_data/events_per_hour.sql")

  
  # 3.2 Hive Input -----------
  withProgress(message = "Extracting Advertiser Events data from Hive", value = 0, {
    
    get_kerberos_token(password = passwd())
    # set_criteo_psw()
    hive_data <- pull_data_hive(query = hive_query, 
                                username = user(), 
                                prefix = paste0("hive_temp_", input$hive_name))
    save(hive_data, file = paste0('Modules/Hive_data/loaded_hive_data_', input$hive_name, '_', no_parts, 'splits.rda'))
  })
  
  # Output text for saved data 
  output$saved_hive <- renderText({
    
    return('Hive data is saved in folder \'Modules/Hive_data/ \'')
    
  })
  
  # Remove pswd file 
  if(file.exists(paste0("C:/Users/", user(), "/windows-credentials.txt")))
    file.remove(paste0("C:/Users/", user(), "/windows-credentials.txt"))
  
} else {
  
  # Load already extracted hive data 
  load(paste0("Modules/Hive_data/loaded_hive_data_", input$hive_name, ".rda"))
  
}

input_hive <- hive_data

colnames(input_hive) <- gsub("t1.", "", colnames(input_hive))


# 4. Formating Hive ------------------------------
input_hive$clicks = as.numeric(as.character(input_hive$clicks))
input_hive$adv_cost_euro=as.double(input_hive$adv_cost_euro)
input_hive$min_timestamp=as.POSIXct(input_hive$min_zeitstempel, format = "%Y-%m-%d %H:%M:%S")
input_hive$max_timestamp=as.POSIXct(input_hive$max_zeitstempel, format = "%Y-%m-%d %H:%M:%S")
input_hive$min_zeitstempel = NULL
input_hive$max_zeitstempel = NULL
input_hive = as.data.table(input_hive)
input_hive$split1 = 1

# Set reactive hive input after the selected nr of parts for the uplift analysis
react_input_hive = reactive({
  
  # Check if hive data is for the same date range as selected. If not adjust to manual 
  # selection
  if(!input$add_settings){
    if(any(input$dates_data != c(min(as.Date(input_hive$day), na.rm = TRUE), 
                                 max(as.Date(input_hive$day), na.rm = TRUE)))){
      input_hive <- input_hive[as.Date(day) >= input$dates_data[1] & as.Date(day) <= input$dates_data[2]]
    }
  }
  
  # edit number of splits to manual selection or max number
  if(is.null(input$select_no_splits_per_hour)){
    nr_splits = input$max_splits_per_hour
  } else {
    nr_splits = input$select_no_splits_per_hour
  }
  
  # Aggregate hive data by hour splits
  out = input_hive[, .(
    distinct_user_ids = sum(distinct_user_ids, na.rm = TRUE), 
    transactions = sum(transactions, na.rm = TRUE), 
    events = sum(events, na.rm = TRUE), 
    clicks = mean(clicks, na.rm = TRUE), 
    adv_cost_euro = mean(adv_cost_euro, na.rm = TRUE),
    min_timestamp = min(min_timestamp), 
    max_timestamp = max(max_timestamp)
  ), 
  by = .(day, stunde, eval(parse(text = paste0("split", nr_splits))))]
  colnames(out)[grep("parse", colnames(out))] = "part"
  
  out$part[which(out$part == 0)] = 1
  
  return(list(hive_hour = out))
  
})


# Final prep of mediaplan ------------------------
# Edit mediaplan to selected number of splits reactively
react_input_mediaplan = reactive({
  
  # Select number of splits per hour
  if(is.null(input$select_no_splits_per_hour)){
    no_parts = input$max_splits_per_hour
  } else {
    no_parts = input$select_no_splits_per_hour
  }
  
  # splits the hour into selected parts
  breaks = c(0, seq(60 / no_parts, 60, length.out = no_parts))
  input_mediaplan$part = cut(minute(input_mediaplan$timestamp), breaks, labels = 1:no_parts)
  na_parts = which(is.na(input_mediaplan$part))
  input_mediaplan$part[na_parts] = 1
  
  # Filter for city
  if(!is.null(input$city)){
    input_mediaplan <- subset(input_mediaplan, City == input$city)
  }
  
  return(input_mediaplan)
  
})

date_range = c(start_date, end_date)
