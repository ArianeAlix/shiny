#' Data Aggregation 
#' 
#' Data is first aggregated per hour and then per day. Afterwards 
#' the data is plotted as the coefficient (e.g. events) per day
#' Second plot is the ratio of spots per day with an event timeline
#' 
#' @param data_all Merged data.table of mediaplan and hive data
#' @param input reactive input by shiny
#' @param output reactive output by shiny
#' @return 
#' @author Conrad Quandel <c.quandel@@criteo.com>
#' 

# 1. Aggregation per Hour --------------------------
react_data_hour_all <- reactive({
  data_all = react_data_all()
  
  data_hour_all <- data_all[,.(
    numb_spots_help1=max(is.na(Channel)),
    numb_spots_help2=length(Channel),
    user=mean(distinct_user_ids, na.rm=TRUE),
    transactions=mean(transactions, na.rm=TRUE),
    events=mean(events, na.rm=TRUE),
    clicks=mean(clicks, na.rm=TRUE),
    adv_cost_euro=mean(adv_cost_euro, na.rm=TRUE)
  ),
  by=.(Hour, Date, min_timestamp, max_timestamp, part)]
  
  # Calculate number of spots per hour
  data_hour_all$numb_spots = ifelse(data_hour_all$numb_spots_help1 == 1, 0, data_hour_all$numb_spots_help2)
  data_hour_all$numb_spots_help1 = NULL
  data_hour_all$numb_spots_help2 = NULL
  data_hour_all = unite(data_hour_all, col = "date_hour", c("Date", "Hour"), remove = FALSE, sep = " / ")
  
  return(data_hour_all)
})

# 2. Aggregation per Day -------------------
react_data_day_all <- reactive({
  data_hour_all <- react_data_hour_all()
  
  # Aggregate data per day
  data_day_all <- data_hour_all[,.(
    numb_spots=sum(numb_spots),
    user=sum(user, na.rm=TRUE),
    transactions=sum(transactions, na.rm=TRUE),
    events=sum(events, na.rm=TRUE),
    clicks=sum(clicks, na.rm=TRUE),
    adv_cost_euro=sum(adv_cost_euro, na.rm=TRUE)
  ),
  by=.(Date)]
  
  
  # Spot and coefficient Ratio for plot
  data_day_all$numb_spots_ratio <- data_day_all$numb_spots / sum(data_day_all$numb_spots)
  data_day_all$events_ratio <- data_day_all$events / sum(data_day_all$events)
  data_day_all$clicks_ratio <- data_day_all$clicks / sum(data_day_all$clicks)
  data_day_all$transactions_ratio <- data_day_all$transactions / sum(data_day_all$transactions)
  
  return(data_day_all)
})



# 3. Quick check of events per day -------------------
output$plot_aggr_total <- renderPlot({
  
  data_day_all <- react_data_day_all()
  
  # set maximum label and number of labels
  max_label <- round_any(max(data_day_all[, .(eval(parse(text = input$coeff)))]), 
                         accuracy = 10000, f = ceiling)
  by_label <- max_label / 5
  
  # plot number of events per day
  g_check <- ggplot(data_day_all, aes_string(x = "Date", y = paste(input$coeff)))
  plot_aggr_total <- g_check + 
    geom_line(colour="#cbcdcd", size=1.2) + 
    theme_bw() + 
    theme(axis.text = element_text(size = 12), axis.title = element_text(size = 14)) +
    # set y axis breaks and labels
    scale_y_continuous(str_to_title(input$coeff), 
                       breaks = seq(0, max_label, by = by_label), 
                       label = format(seq(0, max_label, by = by_label), big.mark = "."))
  
  react_plot_aggr_total(plot_aggr_total)
  plot_aggr_total
  
})


# 4. Plot Number Spots with events per day ---------------
output$plot_aggr_ratio <- renderPlot({
  
  data_day_all <- react_data_day_all()
  
  data_day_all_new <- as.data.frame(data_day_all)
  data_day_all_new <- data_day_all_new[, c("Date", "numb_spots_ratio", input$ratio)]
  
  plot_aggr_ratio <- ggplot(data_day_all, aes(x = Date)) +
    geom_bar(aes(y = numb_spots_ratio, fill = "Spots"), stat = "identity") +
    geom_line(aes(y = data_day_all_new[, input$ratio], color = paste( stri_trans_totitle( stri_split_regex(input$ratio, "_")[[1]][1]))), 
              size = 1.5) + 
    geom_text(
      data = subset(data_day_all, numb_spots != 0),
      aes(x = Date, y = numb_spots_ratio + max(numb_spots_ratio) * 0.02, label = numb_spots), 
      colour = '#535454'
    ) +
    labs(x = "",y = "Ratio per day", color = "") +
    scale_color_manual(values = c("#ff8f1c")) + 
    scale_fill_manual(values = c("#cbcdcd")) + 
    ggtitle("") + 
    theme_bw() + 
    theme(
      axis.text = element_text(size = 12), 
      axis.title = element_text(size = 14), 
      legend.title = element_blank(), 
      legend.text = element_text(size = 12)
    )
  
  react_plot_aggr_ratio(plot_aggr_ratio)
  plot_aggr_ratio
  
})
