select
timestamp,
received_timestamp,
broadcast_timestamp,
tv_tracking_provider,
partner_id,
broadcast_duration_sec,
country,
ad_brand,
spot_name,
tv_channel_name,
prev_program,
next_program,
genre
from
self_central_eu_t1.tvty_tracking_data
--glup.tv_ad_schedule
where day >= __start_date__ and day <= __end_date__ and partner_id = __partner_id__;
