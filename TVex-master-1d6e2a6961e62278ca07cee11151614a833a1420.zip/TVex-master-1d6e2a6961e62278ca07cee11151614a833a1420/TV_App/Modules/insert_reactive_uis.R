#' Insert UIs
#' 
#' Additional script to insert all uis that reactively depending on the input data
#' 

# Select City/Region
if(any("City" %in% colnames(react_input_mediaplan()))){
  insertUI(
    selector = '#city_filter', 
    ui = selectInput("city", label = "City Filter", 
                     choices = c(NULL, unique(react_input_mediaplan()$City)), 
                     selected = "Mockba")
  )
}


# Select splits per Hour
insertUI(
  selector = '#selected_splits_per_hour', 
  ui = numericInput("select_no_splits_per_hour", label = h4("Select splits per hour"), 
                    min = 1, max = input$max_splits_per_hour, 
                    value = input$max_splits_per_hour)
)


# Selection of channels ---------------------------
output$channel_spots <- renderDataTable({
  
  react_channel_spots()
  
})

# Channel for top programs
output$channels_topProgram <- renderUI({
  tagList(
    selectInput("select_channel_topProgram", 
                label = "Select Channel:", 
                choices = c("All", react_channel_spots()$Channel), 
                selected = "All")
  )
})

# Channel for extreme program
output$channels_extremeProgram <- renderUI({
  selectInput("select_channel_extremeProgram", 
              label = "Select Channel:", 
              choices = c("All", react_channel_spots()$Channel), 
              selected = "All")
})

# Channel for barplots
output$channels_barplotUplift <- renderUI({
  selectInput("select_channel_barplotUplift", 
              label = "Select Channel:", 
              choices = react_channel_spots()$Channel, 
              selected = react_channel_spots()$Channel[1])
})

# Number of channels 
output$nr_channels <- renderUI({
  numericInput("select_channels", "Select the number of channels (descending order):",
               value = ifelse(nrow(react_channel_spots()) <= 20, nrow(react_channel_spots()), 20), 
               min = 0, max = nrow(react_channel_spots()))
})

# Toggle state of select channels
observe({
  if(length(input$channe_spots_rows_selected) > 0){
    disable(id = 'select_channels')
  } else {
    enable(id = 'select_channels')
  }
})

# type of Uplift 
insertUI(
  
  selector = '#uplift_norm', 
  ui = selectInput("selectUplift", h4("Select type of uplift analysis"), 
                   choices = c("Uplift Events" = "uplift_events",  
                               "Uplift Transactions" = "uplift_transactions"))
)

# Choose Month for plots 
data_uplift2 <- react_uplift_calculation()
if(length(unique(data_uplift2$month)) > 1){
  month_choices <- c("All", unique(data_uplift2$month))
} else {
  month_choices <- unique(data_uplift2$month)
}
insertUI(
  
  selector = '#month', 
  ui = selectInput("selectMonth", h4("Select month:"), 
                   choices = month_choices
  )
  
)

# Select Weekday
insertUI(
  
  selector = '#weekday', 
  ui = selectInput("selectWeekday", h4("Select Weekday:"), 
                   choices = c("All", unique(as.character(data_uplift2$dayofweek))), 
                   selected = "All")
)

# select percentage of points shown in uplift depending on budget
insertUI(
  
  selector = '#uplift_perc_spots', 
  ui = numericInput("uplift_percentage_of_points", 
                    label = "Select threshold for percentage of points shown:", 
                    value = 25, min = 0, max = 100)
  
)

# Budget Analysis 
if(input$budget_analysis){
  insertUI(
    
    selector = '#budgetOrder', 
    ui = selectInput(inputId = "order_budget_col", label = "Choose Column to order top Programs by: ", 
                     choices = colnames(react_table_budget_per_program())[3:5], 
                     selected = colnames(react_table_budget_per_program())[5])
    
  )
}


