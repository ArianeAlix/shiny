# Gloabal File Everything in here will automatically loaded. 

options(shiny.maxRequestSize=8*1024^2) 
options(java.parameters = "-Xmx4g") 

# 1. Loading Packages----------------------
library(shiny)
library(shinydashboard)
library(shinyBS)
library(shinyjs)

library(data.table)
library(ggplot2)
library(CriteoRBase)
library(RJDBC)
library(TTR)
library(ggplot2)
library(xts)
library(zoo)
library(gridExtra)
library(reshape)
library(scales)
require(MASS)
library(dplyr)
library(readr)
library(xlsx)
library(lubridate)
library(tidyr)
library(stringi)
library(stringr)
library(DT)
library(shinyjs)
library(forecast)
library(tools)

library(officer)
library(flextable)
library(rvg)

# 1.1 Set Options for Powerpoint ----------------------------
options("ReporteRs-default-font" = "Arial")
options("ReporteRs-default-fontsize" = 12)

# 2. Basic functions ------------------------

# 2.1 Send Mail Function -----------------------
#' Function to send mail via criteo server
#' 
#' @param username
#' @param recipient
#' @param cc
#' @param bcc
#' @param subject
#' @param body
#' @param attachmentFile
#' @param passwort
#' @return send mail to recipient mail adress
#' 
sendEmail <- function(username = "f.last",
                      recipient = "f.last@wherever.com",
                      cc = NULL,
                      bcc = NULL,
                      subject = " ",
                      body = " ",
                      attachmentFile = NULL,
                      password = NULL) {
  if (is.null(password)) {
    password <- .rs.askForPassword("Criteo password: ")
  }
  send.mail(
    from = paste0(username, "@criteo.com"),
    to = recipient,
    cc = cc,
    bcc = bcc,
    subject = subject,
    body = body,
    attach.files = attachmentFile,
    smtp = list(
      host.name = "smtp.criteois.lan",
      port = 25,
      user.name = paste0(username, "@criteo.com"),
      passwd = password,
      tls = TRUE
    ),
    authenticate = TRUE
  )
}

# 2.2 Transform Time column function  --------------------------
#' Function to prepare times to regular times. 
#' 
#' @param input_mediaplan Mediaplan with Times to replace
#' @param time_col column which includes the times. 
#' @return input_mediaplan
#' @author Conrad Quandel <c.quandel@@criteo.com>
#' 
#'
transform_times <- function(input_mediaplan, time_col){
  
  desired_col <- input_mediaplan[, time_col]

  res <- data.table(stringi::stri_split_regex(desired_col, ":", simplify = TRUE))
  colnames(res) <- c("hour", "minute")
  
  # Correct hour informations
  if(any(res$hour >= 24)){
    
    res[hour >= 24, 1] <- res[hour >= 24, as.character(as.numeric(hour) - 24)]
    res$hour[nchar(res$hour) == 1] <- paste0("0", res$hour[nchar(res$hour) == 1])
    
  }
  
  # Correct minute informations
  if(any(res$minute >= 60)){
    
    res[minute >= 60, 2] <- res[minute >= 60, as.character(as.numeric(minute) - 60)]
    res$minute[nchar(res$minute) == 1] <- paste0("0", res$minute[nchar(res$minute) == 1])
    
  }
  
  input_mediaplan[, time_col] <- unite(as.data.frame(res), col = time_col, hour, minute, sep = ":", remove = TRUE)
  return(input_mediaplan)
  
}

# Scale Colours Manual ------------------
TV_color_theme = c("#f78b2c", "#fcbc2b", "#05b996", "#00a9cd", "#005581", "#B40303", "#373c42", 
                   "#727983", "#c9470b", "#048b71", "#007f9a", "#00e7e2", 
                   "#FF5C5C", "#004ED4", "#a76464", "#5ace61", "#00d00e", "#a358a7", "#049dfb", 
                   "#93ae07")


