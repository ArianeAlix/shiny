
# 0.1 Start Shiny App ---------------------------------
shinyServer(function(input, output, session) {
  
  Sys.setlocale(category = "LC_TIME", locale = "English")
  
  # Input Credentials and test for connectivity
  user <- reactiveVal("")
  passwd <- reactiveVal("")
  react_plot_uplift_per_channel <- reactiveVal()
  react_plot_ref_lines <- reactiveVal()
  react_plot_aggr_total <- reactiveVal()
  react_plot_aggr_ratio <- reactiveVal()
  react_plot_channel_weekday <- reactiveVal()
  react_plot_channel_week <- reactiveVal()
  
  react_media <- reactiveVal(data.frame())
  
  
  # source tooltips -----------------
  source("./Modules/tooltips.R", local = TRUE)
  
  # display already loaded hive catalogs
  # Read all files in Hive_data folder and then filter for loaded hive data
  catalog = c(tables = list.files(path = "./Modules/Hive_data", pattern = "\\.rda"))
  catalog = catalog[grep("loaded_hive", catalog)]
  catalog = str_replace(catalog, "loaded_hive_data_", "")
  catalog = str_replace(catalog, ".rda", "")
  
  catalog = data.frame(catalog)
  
  output$existingData = DT::renderDataTable(
    
    DT::datatable(catalog, selection = list(mode = 'single', target = 'row'))
    
    
  )
  
  # update hive naming via click in table of already existing data
  observeEvent(input$existingData_rows_selected, {

    updateTextInput(session, 'hive_name', value = catalog$catalog[input$existingData_rows_selected])

  })
  
  
  # display already loaded tvty mediaplan
  tvty_media <- c(tables = list.files(path = "Modules/TVTY_data", pattern = "\\.csv"))
  tvty_media <- tvty_media[grep("loaded_tvty", tvty_media)] %>%
    str_replace("loaded_tvty_data_", "") %>%
    str_replace(".csv", "")
  
  tvty_media <- data.frame(tvty_media)
  
  output$tvty_mediaplan <- DT::renderDataTable(
    
    DT::datatable(tvty_media, selection = list(mode = 'single', target = 'row'))
    
  )
  
  
  # Example Data -----------------------------------
  # Display example data for mediaplan format
  output$example_data <- renderTable({
    
    example_data <- data.frame(Channel = "ARD", weekday = "Monday", Date = format(Sys.Date(), "%d.%m.%Y"), 
                               Time = format(Sys.time(), "%H:%M"), Advertiser = "AboutYou", 
                               Program = "Mike & Molly / Mike & Molly")
    example_data
    
  })
  
  # Raw Mediaplan ----------------------------
  # show header of mediaplan to see if changes in format have to be made.
  output$raw_mediaplan <- renderDataTable({

    inFile <- input$mediaplan$datapath
    
    # if inFile does not exist, nothing is loaded and nothing should be displayed
    if(is.null(inFile)) return(NULL)
    
    # Read in transform time a bit
    media <- openxlsx::read.xlsx(inFile, sheet = 1, detectDates = TRUE, rows = 1:6)
    if(all(is.na(as.numeric(media$Time)))){
      media$Time <- format(media$Time)
    } else {
      media$Time <- format(as.POSIXct(as.numeric(media$Time) * 24 * 60 * 60, origin = "1970-01-01", tz = "UTC"), "%H:%M") 
    }
    
    # display as datatable
    react_media(media)
    if(exists("media") == TRUE){
      return(datatable(media, selection = list(mode = "single", target = "column") ))
    } 

  })
  
  # Uploaded spotwatch data --------------------------------
  output$raw_spotwatch <- renderDataTable({
    
    inFile <- input$spotwatch$datapath
      
    if(is.null(inFile)) return(NULL)
    media <- read.csv2(inFile)
    if (exists("media")){
      return(datatable(media, selection = list(mode = "single", target = "column")))
    }
 
  })
  
  # Possibility to select column if budget analysis should be done
  observeEvent(input$raw_mediaplan_columns_selected, {
    
    updateTextInput(session, 'budget_column', value = colnames(react_media())[input$raw_mediaplan_columns_selected])
    
  })
  
  # if hive data will be extracted (either for tvty or events table), credentials 
  # needs to be defined and so by pressing the log in action button an pop up window
  # shows up
  observeEvent(input$logIn, {
    popup_credentials <- modalDialog(
      title = 'Hive Credentials',
      textInput('user', label = "Username", value = Sys.getenv("USERNAME")), 
      passwordInput("passwd", label = "Password", value = ""), 
      textOutput("connectionError"), 
      textOutput("errortype"), 
      footer = actionButton("vertica_ok", 'Ok'), 
      easyClose = FALSE
    )
    showModal(popup_credentials)
    
    # Via a simple query credentials are checked
    observeEvent(input$vertica_ok, {
      tryCatch({
        pull_data_vertica(
          "SELECT * FROM bi_core.dim_country limit 0;", 
          isTS = FALSE, 
          username = input$user, 
          password = input$passwd
        )
        user(input$user)
        passwd(input$passwd)
        removeModal()
        shinyjs::hide("logIn", anim = TRUE, animType = "slide")
      }, 
      error = function(e){
        output$connectionError <- renderText("Connection error:")
        errortype <- renderText(e$message)
        output$errortype <- errortype
      })
    })
  })
  
    
    

  # 1. Start Analysis ---------------------
  observeEvent(input$start_analysis, {
    
    # browser()
    # Data loading ------------------------------
    source("Modules/data_loading.R", local = TRUE)
    
    
    
    # Merge Hive and mediaplan ------------------------
    react_data_all <- reactive({
      
      input_hive = react_input_hive()$hive_hour
      input_mediaplan = react_input_mediaplan()
      
      # merge mediaplan and hive data by Date, hour and part
      data_all = merge(input_mediaplan, input_hive, by.x=c("Date", "Hour", "part"), 
                       by.y=c("day", "stunde", "part"), all=TRUE)
      data_all = data.table(data_all)
      
      # set number of splits reactively either of max splits or if changed by selected number
      if(is.null(input$select_no_splits_per_hour)){
        nr_splits = input$max_splits_per_hour
      } else {
        nr_splits = input$select_no_splits_per_hour
      }
      
      # hour is splitted by number of selected splits
      data_all$hour_split = data_all$Hour + 
        round((as.numeric(data_all$part) - 1) / 60 * (60 / nr_splits), digits = 2)
      write.csv2(data_all,file = 'data_all.csv')
      return(data_all)
      
    })
    
    
    # Budget Analysis -------------------------
    if(input$budget_analysis){
      
      source("Modules/budget_analysis.R", local = TRUE)

    }
    
    
    # Data Aggregation -------------------------------
    source("Modules/data_aggregation.R", local = TRUE)
    
    
    
    # Uplift Analysis ------------------------------
    source("Modules/uplift_analysis.R", local = TRUE)
    
    
    # Uplift per program and channel ---------------
    source("Modules/Uplift_per_program_channel.R", local = TRUE)
    
    
    # Reactive UIs
    source("Modules/insert_reactive_uis.R", local = TRUE)
    
    
    # # Difference between spotwatch and tvty uplift
    # source("Modules/uplift_diff.R", local = TRUE)
    
    
    # Analysis is done ---------------------------
    output$AnalysisDone <- renderText({
      
      return('Analysis is done: See results in the other Menu Items.')
      
    })
    
    # 2. Powerpoint Export ------------------------
    # set output name by tracking provider input name 
    if(input$tracking_provider == 'mediaplan'){
      output_name <- input$advertiser_name
    } else {
      output_name <- ""
    }
      
    # Download ppt ---------------
    output$out_pptx <- downloadHandler(
      # define file name of ppt
      filename = function() {
        paste0(gsub(" ", "_", output_name), "_TV_Analysis.pptx")
      }, 
      
      content = function (file){
        
        # Set progress bar and create ppt presentation
        withProgress(message = 'Generating TV Analysis Powerpoint Presentation', value = 0, {
          
          source('Modules/ppt_creation.R', local = TRUE)
          
        })
        
        # write ppt intoo tempfile and download into local download folder
        my_temp_file = tempfile(fileext = ".pptx")
        print(mydoc, target = my_temp_file)
        file.rename(from = my_temp_file, to = file)
        
        # Show message that download was succesfull
        showModal(modalDialog(
          paste("PPT document has been successfully produced and downloaded to your 'Download' folder.")
          ,
          title = "Success"
          ,
          easyClose = TRUE
        ))
      }
    )
    
    # Download Uplift data in xlsx file ----
    output$out_xlsx <- downloadHandler(
      # define filename for xlsx file
      filename = function() {
        paste0(gsub(" ", "_", output_name), "_TV_Analysis_top_programs.xlsx")
      }, 
      
      content = function (file){
        
        my_temp_file = tempfile(fileext = ".xlsx") 
        # browser()
        
        withProgress(message = 'Generating Excel with uplift data', value = 0, {
          
          # Choose uplift data 
          all_uplift_data <- react_uplift_calculation()[, list(Date, dayofweek, timestamp, Channel, Program, uplift_events)]
          nr_channels <- length(unique(all_uplift_data$Channel)) + 1
          
          # Write all data into temp file
          write.xlsx2(all_uplift_data, file = my_temp_file, sheetName = "All", append = FALSE, row.names = FALSE)
          incProgress(1 / nr_channels, detail = "Uplift Data for all data written")
          
          # Write data into xlsx channel by channel
          for(channel in unique(all_uplift_data$Channel)){
            channel_data <- all_uplift_data[channel, on = .(Channel)]
            write.xlsx2(channel_data, file = my_temp_file, sheetName = channel, append = TRUE, row.names = FALSE)
            
            incProgress(1 / nr_channels, detail = paste("Uplift Data for Channel", channel, "written"))
          }
          
        })
        
        # write into download folder
        file.rename(from = my_temp_file, to = file)
        
        # Show message that download of xlsx is finished
        showModal(modalDialog(
          paste("XLSX document has been successfully produced and downloaded to your 'Download' folder.")
          ,
          title = "Success"
          ,
          easyClose = TRUE
        ))
      })
        
  })

})
