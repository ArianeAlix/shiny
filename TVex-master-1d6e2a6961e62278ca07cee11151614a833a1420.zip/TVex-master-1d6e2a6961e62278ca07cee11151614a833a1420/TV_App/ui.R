# User Interface for TV analysis


# 1. Header ------------------------------
header <- dashboardHeader(title = "TV Analysis", 
                          tags$li(a(href = 'https://www.criteo.com/',
                                    img(src = 'criteo_rgb.png', 
                                        height = 37, width = 135)),
                                  class = "dropdown"),
                          titleWidth = 300
                          )

# 2. Sidebar ----------------------------
# Sets interface menu 
sidebar <- dashboardSidebar(
  sidebarMenu(
    style = "position: fixed; overflow: visible;", 
    
    # Input tab
    menuItem(
      'Inputs', tabName = 'inputs', icon = icon('file-excel-o')
    ), 
    
    # Aggregation tab
    menuItem(
      'Aggregation', tabName = 'aggregation', icon = icon('bar-chart')
    ),
    
    # Uplift Analysis tab
    menuItem(
      'Uplift Analysis', tabName = 'uplift', icon = icon('line-chart'), 
       menuSubItem('Pre TV Spot Period', tabName = 'preTV', icon = icon('chrome')), 
       menuSubItem('Uplift for Channels', tabName = 'up_channels', icon = icon('tv'))
    ), 
    
    # Analysis of Programs per Channel
    menuItem(
      "Analysis Programs", tabName = "programs", icon = icon('play-circle'), 
       menuSubItem("Performance of Programs", tabName = "top20", icon = icon('list-ol')),
       menuSubItem("Barplots of Performance", tabName = "barplots_uplift_program", icon = icon("bar-chart")),
       menuSubItem("Extreme Performance of Programs", tabName = "extremePrograms", icon = icon("ambulance"))
    ),
    
    # Budget Analysis
    menuItem(
      "Budget Analysis", tabName = "budget", icon = icon('money'), 
       menuSubItem('Weekly Analysis', tabName = 'budget_per_week', icon = icon('calendar')), 
       menuSubItem('Top Programs by Budget', tabName = 'budget_top_programs', icon = icon('reorder')), 
       menuSubItem("Budget spent per weekday and channel", tabName = 'budget_per_weekday', icon = icon('calendar-check-o'))
    ),
    
    # Output and Documentation
    menuItem('Powerpoint Presentation', tabName = 'ppt_export', icon = icon('file-powerpoint-o')), 
    menuItem('Documentation', tabName = 'docu', icon = icon('copyright'))
  ), 
  width = 300
)

# 3. Body --------------------------------------------
# Defines the interfaces of the single tabs
body <- dashboardBody(
  tabItems(
    ## 3.1 Inputs ------------------------------------
    tabItem(tabName = 'inputs', 
            
            # Mediaplan/TVTY/Spotwatch input tab -----------------------
            fluidRow(
              shinyjs::useShinyjs(),
              
              # Select which tracking provider is used
              column(
                3, box(
                  title = "Tracking Provider", solidHeader = TRUE, status = 'primary', width = NULL,
                  radioButtons(
                    inputId = 'tracking_provider', label = 'Select Tracking Provider:',
                    choices = c('TVTY' = 'tvty', 'Spotwatch' = 'spotwatch', 'Mediaplan' = 'mediaplan'), 
                    selected = 'mediaplan', inline = TRUE
                  )
                )
              ), 
              
              # If TVTY is tracking provider or use hive is selected then show box for input credential
              # to hive and field for partner ID input
              conditionalPanel(
                condition = "input.tracking_provider == 'tvty' || input.use_hive",
                column(
                  3, 
                  box(
                    title = 'Data connection', solidHeader = TRUE, status = 'primary', width = NULL,
                    fluidRow(
                      column(
                        6, numericInput('partnerID', label = 'Set Parnter ID', value = 3663)
                      ), 
                      column(
                        6, actionButton("logIn", label = "Login for Hive", icon = icon("sign-in"))
                      )
                    )
                  )
                )
              ),
              
              
              # If mediaplan is tracking provider
              conditionalPanel(
                condition = "input.tracking_provider == 'mediaplan'",
                box(
                  title = "Upload Mediaplan", solidHeader = TRUE, status = 'primary', width = 12,
                  
                  fluidRow(
                    # File input for Mediaplan excel
                    column(
                      3, fileInput('mediaplan', label = 'File upload')
                    ), 
                    # See insert_reactive_ui for City filter
                    column(
                      3, tags$div(id = 'city_filter')
                    ), 
                    # Timezone select input
                    column(
                      2, selectInput(
                        'timezone', label = "Select Timezone:", 
                        choices = c("Central European Time" = "CET", "Europe/Kaliningrad" = "OEZ", "Europe/Moscow" = "MSK", 
                                    "Europe/Samara" = "SAMT", "Europe/Istanbul" = "TRT",
                                    "Asia/Yekaterinburg" = "YEKT", "Asia/Krasnoyarsk" = "KRAT", 
                                    "Asia/Irkutsk" = "IRKT", "Asia/Yakutsk" = "YAKT", "Asia/Vladivostok" = "VLAT",
                                    "Asia/Srednekolymsk" = "SRET", "Asia/Kamchatka" = "PETT"), 
                        selected = "Europe/Moscow")
                    )
                  ),
                  h5("The following data is an example for how the data should look like. 
                     These columns should exist in the uploaded file and the names should be the same.  
                     The order of the columns is not important. "),
                  br(),
                  
                  # Example Data output
                  tableOutput('example_data'), 
                  br(), br(),
                  h5("If uploaded, output should show the mandatory columns appropriatly. Especially the time column should not be a decimal number. "),
                  
                  # header of input mediaplan output
                  dataTableOutput('raw_mediaplan')
                )
              ),
              
              # Display box for spotwatch tracking
              conditionalPanel(
                condition = "input.tracking_provider == 'spotwatch'",
                box(
                  title = "Upload spotwatch tracking plan", solidHeader = TRUE, status = 'primary', width = 12,
                  
                  fluidRow(
                    # File input for spotwatch io downloaded csv
                    column(
                      3, fileInput('spotwatch', label = 'File upload (wait some seconds to show File output)')
                    ), 
                    # Timezone for time adjustement select input
                    column(
                      2, selectInput(
                        'timezone_spotwatch', label = "Select Timezone:", 
                        choices = c("UTC" = "UTC", "Central European Time" = "CET", "Europe/Kaliningrad" = "OEZ", 
                                    "Europe/Moscow" = "MSK", "Europe/Samara" = "SAMT", 
                                    "Asia/Yekaterinburg" = "YEKT", "Asia/Krasnoyarsk" = "KRAT", 
                                    "Asia/Irkutsk" = "IRKT", "Asia/Yakutsk" = "YAKT", "Asia/Vladivostok" = "VLAT",
                                    "Asia/Srednekolymsk" = "SRET", "Asia/Kamchatka" = "PETT"), 
                        selected = "Central European Time")
                    )
                  ),
                  
                  br(), 
                  
                  # Table output of spotwatch mediaplan input file - header
                  h5("Uploaded spotwatch mediaplan"),
                  dataTableOutput('raw_spotwatch')
                )
              ), 
              
              # Display box for TVTY tracking
              conditionalPanel(
                condition = "input.tracking_provider == 'tvty'", 
                box(
                  title = "Upload or Extract tvty tracking plan", solidHeader = TRUE, status = 'primary', width = 12,
                  
                  fluidRow(
                    # Select daterange of tv spots
                    column(
                      3, dateRangeInput(
                        inputId = "tvty_daterange", 
                        label = "Select date range for TVTY data", 
                        start = Sys.Date() - 31, end = Sys.Date() - 1
                      ), 
                      # Timezone for tvty time adjustment
                      selectInput(
                          'timezone_tvty', label = "Select Timezone:", 
                          choices = c("UTC" = "UTC", "Central European Time" = "CET", "Europe/Kaliningrad" = "OEZ", 
                                      "Europe/Moscow" = "MSK", "Europe/Samara" = "SAMT", 
                                      "Asia/Yekaterinburg" = "YEKT", "Asia/Krasnoyarsk" = "KRAT", 
                                      "Asia/Irkutsk" = "IRKT", "Asia/Yakutsk" = "YAKT", "Asia/Vladivostok" = "VLAT",
                                      "Asia/Srednekolymsk" = "SRET", "Asia/Kamchatka" = "PETT"), 
                          selected = "Central European Time")
                    ), 
                    # Table output of already loaded tvty mediaplans
                    column(
                      4, DT::dataTableOutput("tvty_mediaplan")
                    )
                    
                  ), 
                  
                  fluidRow(
                    column(
                      8, DT::dataTableOutput("raw_tvty")
                    )
                  )
                  
                )
              )
            ),
              
            
            
            fluidRow(
              
              # Set Settings for Hive Data Extraction ---------------------------
              column(
                4, box(
                  title = "Settings for Hive Data", solidHeader = TRUE, status = 'primary', width = NULL, 
                  
                  # Explanational Text
                  fluidRow(
                    column(
                      12, h5("Extracting data from Hive will need around 20 min. Before you have to define the filename for the Hive Data. \n
                             If you have already loaded the data, you can type in the name or just select a row in the table below. ")
                    )
                  ),
                  
                  # Checkbox for hive extraction
                  fluidRow(
                    column(
                      6, checkboxInput('use_hive', label = 'Extract data from Hive. ', value = FALSE)
                    )
                  ),
                  
                  # Type file name for hive events extraction
                  fluidRow(
                    column(
                      12, textInput("hive_name", label = "Define the file name of the Hive extract:", placeholder = "fossilDE"))
                  ), 
                  
                  # Already extracted hive tables. 
                  fluidRow(
                    column(
                      12, DT::dataTableOutput("existingData")
                    )
                  )
               )
             ), 
              
              
            # Additional Settings for Analysis ------------------------
            column(
              4, box( # Additional Settings box
                title = "Additional Settings for Analysis", solidHeader = TRUE, status = 'primary', width = NULL, 
                
                # Select splits per hour for events
                fluidRow(
                  column(
                    10, numericInput("max_splits_per_hour", label = "Select maximum number of splits per Hour", 
                                   min = 0, max = 6, value = 6)
                  )
                ), 
                
                # Checkbox if budget Analysis should be done
                checkboxInput('budget_analysis', label = "Budget Analysis (Data has to be available)", 
                              value = FALSE),
                # Type in budget column name
                conditionalPanel(
                  condition = 'input.budget_analysis', 
                  fluidRow(
                    column(
                      10, textInput('budget_column', 
                                   label = "Write column to be used for budget analysis", 
                                   placeholder = 'tarif')
                    )
                  )
                ),
                
                # Select if additional settings should be used
                tags$span(
                  popify(
                    checkboxInput('add_settings', label = 'Standard settings', value = TRUE), 
                    trigger = "hover", placement = "bottom", options = list(container = "body"), 
                    title = "", content = ""
                  )
                ),
                
                # If add settings is selected provide manual date range for events data
                conditionalPanel(
                  condition = '!(input.add_settings)', 
                  fluidRow(
                    column(
                      8, dateRangeInput(
                        'dates_data', label = 'Select date range manually: ', 
                        start = Sys.Date() - 100, end = Sys.Date())
                    )
                  )
                )
              ), 
              
              
              # Start Analysis-------------------
              box(
                title = "Start Analysis",
                
                # Text Input for saving file name
                textInput('advertiser_name', label = 'Advertiser Name:'),
                actionButton('start_analysis', 'Start Analysis'), 
                textOutput('saved_hive'),
                textOutput('AnalysisDone'),
                width = NULL, collapsible = TRUE, solidHeader = TRUE, status = 'primary'
              )
            )
          )
    ),
    
    ## 3.2 Aggregation -------------------------
    tabItem(tabName = 'aggregation', 
            fluidRow(
              column(12, 
                     
                     # Plot coefficient of date range
                     box(
                       title = 'Number of Events', solidHeader = TRUE, status = 'primary', 
                       
                       checkboxInput("ppt_include_aggr_total", label = "Include in PPt: ", value = TRUE),
                       
                       selectInput(inputId = "coeff", label = "Select preferred coefficient", 
                                   choices = c("Events" = "events", 
                                               "Clicks" = "clicks", 
                                               "Transactions" = "transactions")),
                       
                       plotOutput('plot_aggr_total')
                     )
              ), 
              
              column(12, 
                     
                     # Plot Ratio of spots per day with total events per day
                     box(
                       title = 'Ratio of spots with events per day', solidHeader = TRUE, status = 'primary',
                       
                       checkboxInput("ppt_include_aggr_ratio", label = "Include in PPt: ", value = TRUE),
                       
                       selectInput(inputId = "ratio", label = "Select preferred ratio", 
                                   choices = c("Events Ratio" = "events_ratio", 
                                               "Clicks Ratio" = "clicks_ratio", 
                                               "Transactions Ratio" = "transactions_ratio")),
                       
                       plotOutput('plot_aggr_ratio')
                     )
              )
            )
    ), 
    
    # 3.3 Pre Tv Analysis ------------------------------
    tabItem(tabName = 'preTV', 
            fluidRow(
              # Plot reference lines per weekday per split per hour
              box(
                title = "Events per hour for pre TV period", solidHeader = TRUE, status = 'primary', 
                
                checkboxInput("ppt_include_preTV", label = "Include in PPt: ", value = TRUE),
                
                # selection of average coefficient to plot
                column(
                  6, selectInput("selectAverage", h4("Select the type of the averaging:"),
                                 choices = c("Average User" = "avg_user", "Average Transactions" = "avg_transactions", 
                                             "Average Events" = "avg_events", "Average Clicks" = "avg_clicks", 
                                             "Average Advertisement Costs" = "avg_adv_cost_euro"), 
                                 selected = "avg_events")
                ), 
                
                fluidRow(
                  column(
                    12, plotOutput('ref_lines')
                  )
                )
              )
            )
    ), 
    
    # 3.4 Uplift Analysis ------------------------------
    tabItem(tabName = 'up_channels', 
            useShinyjs(),
            fluidRow(
              # Box for multiple possible selections of month, weekday, uplift norm, number of splits and 
              # finally the plot itself
              box(
                title = "Uplift of Channels", solidHeader = TRUE, status = 'primary',
                
                # See in insert_reactive_uis for selections of month, weekday, splits per hour and uplift norm
                fluidRow(
                  column(
                    6, tags$div(id = 'month')
                  ),
                  column(
                    6, tags$div(id = 'weekday')
                  )
                ),
                fluidRow(
                  column(
                    6, tags$div(id = 'selected_splits_per_hour')
                  ), 
                  column(
                    6, tags$div(id = 'uplift_norm')
                  )
                ),
                
                # Output uplift plot
                column(
                  12, plotOutput("uplift_per_channel")    
                ), 
                br(),
                
                hr(strong("Options")), 
                helpText("You can select the channels to be shown in different ways. First is to select just the number of channels 
                         in descending order. Second is to select the channels in the table on the right side. Only these channels are 
                         shown. If you select a channel in the table you are not able to use the numeric Input below. \n\n You can also
                         choose the number of points to be shown. This is selected via the percentage of the budget. Only the spots with
                         a budget that is higher than the selectet percentage are drawn."),
                
                fluidRow(
                  # Select nr of channels to plot
                  column(
                    6, uiOutput('nr_channels')
                  ),
                  # If budget analysis is used then selection of quantile for spots budget possible
                  conditionalPanel(
                    condition = "input.budget_analysis", 
                    # also see insert_reactive_uis
                    column(
                      6, tags$div(id = 'uplift_perc_spots')
                    )
                  )
                )
                
                
              ), 
              
              column(
                width = 4, 
                
                # Select plot type and if moving average should be used
                box(
                  title = "Additional Settings", solidHeader = TRUE, status = 'primary', width = NULL, 
                  selectInput("plot_type", label = "Select Type of Plot", 
                              choices = c("Boxplot", "Scatterplot", "Scatterplot with Baseline", "Barchart"), 
                              selected = "Barchart"), 
                  checkboxInput("moving_average", label = "Calculate Uplift with moving average", 
                                value = TRUE)
                ), 
                
                # Table for number of spots per Channel, also for selection of channels to be displayed
                box(
                  title = "Spots per Channel", solidHeader = TRUE, status = 'primary', width = NULL,
                  dataTableOutput("channel_spots")
                  
                )
              )
            ), 
            
            fluidRow(
              # Selection box for powerpoint output
              box(
                title = "Select settings for Powerpoint Presentation", solidHeader = TRUE, status = 'primary', 
                
                # Which uplift coefficient should be included in ppt
                column(
                  3, checkboxGroupInput("uplift_settings", label = "Choose Uplift types", 
                                          choiceNames = list("Uplift by Events", "Uplift by Transactions"), 
                                          choiceValues = list("uplift_events", "uplift_transactions"), 
                                          selected = "uplift_events")
                ), 
                # should differentiation of weekdays be included
                column(
                  3, checkboxInput("ppt_include_weekdays", label = strong("Include plots for every weekday"), value = FALSE)
                ), 
                # Select which plot types should be included
                column(
                  6, wellPanel(
                    selectInput("ppt_plots", label = "Select Types of Plot for PPT", 
                                choices = c("Boxplot", "Scatterplot", "Scatterplot with Baseline", "Barchart"), 
                                selected = c("Barchart", "Scatterplot with Baseline"), 
                                multiple = TRUE
                    )
                  )
                )
              )
            )
    ), 
    
    # 3.5 Top 20 Programs ------------------------
    tabItem(tabName = 'top20', 
            # Table of top programs 
            box(
              title = "Top Programs per uplift in events", solidHeader = TRUE, status = 'primary', width = 11,
              
              fluidRow(
                column(
                  3, checkboxInput("ppt_include_top20", label = "Include in PPt: ", value = FALSE)
                )
              ),
              fluidRow(
                column(
                  3, uiOutput("channels_topProgram")
                )
              ),
              
              
              fluidRow(
                column(
                  8, dataTableOutput('top20')
                )
              )
            )
    ),
    
    # Barchart of top programs per channel
    tabItem(tabName = "barplots_uplift_program", 
            
            box(
              title = "Uplift Report by Program", solidHeader = TRUE, status = 'primary', width = 12, 
              
              fluidRow(
                column(
                  3, checkboxInput("ppt_includ_barplotUplift", label = "Include in PPt:", value = TRUE)
                )
              ), 
              
              fluidRow(
                column(
                  3, uiOutput("channels_barplotUplift")
                )
              ), 
              
              fluidRow(
                column(
                  10, plotOutput("uplift_programs_barplot")
                )
              )
            )
    ),
    
    # Extreme Performanging Programs 
    tabItem(tabName = 'extremePrograms', 
            box(
              title = "Extreme Performing Spots", solidHeader = TRUE, status = 'primary', width = 11, 
              
              fluidRow(
                column(
                  3, checkboxInput("ppt_include_extreme_uplift", label = "Include in PPt: ", value = FALSE)
                )
              ),
              fluidRow(
                column(
                  4, numericInput("quantile_extreme_uplift", label = "Select (upper and lower) quantile of extreme performing programs:", 
                                  value = 5, min = 1, max = 10)
                ), 
                column(
                  3, uiOutput("channels_extremeProgram")
                )
              ),
              
              fluidRow(
                column(
                  8, dataTableOutput('extreme_uplift_overview')
                )
              )
            )),
    
    
    # 3.6 Budget Analysis --------------------------------
    
    # 3.6.1 Budget Analysis per week ----------------------------------
    tabItem(tabName = 'budget_per_week', 
            
            # If bduget analysis
            conditionalPanel(
              condition = "input.budget_analysis", 
              
              # Budget Analysis plot for possible years
              box(
                title = "Budget Analysis", solidHeader = TRUE, status = 'primary', width = 12,
                
                # see insert_reactive_uis for year selection
                fluidRow(
                  column(
                    3, tags$div(id = "Year")
                  )
                ),
                
                plotOutput("plot_budget_per_channel"),
                
                # Select if specific date range budget analysis should be provided
                checkboxInput(inputId = "budget_specific", 
                              label = "See Analysis for specific date range", 
                              value = FALSE)
              ),
              
              #  Budget Analysis for specific date range
              conditionalPanel(
                condition = "input.budget_specific",
                
                box(
                  title = "Budget Analysis for chosen week range", solidHeader =  TRUE, status = 'primary', width = 12,
                  
                  # Select date range for budget analysis
                  fluidRow(
                    column(
                      3, sliderInput(inputId = 'budget_week_range', label = "Choose week range for budget analysis:", 
                                     min = 1, max = 52, value = c(20, 25))
                    )
                  ), 
                  
                  plotOutput("plot_budget_week_range")
                  
                )
              )
            ),
            
            # If no budget analysis is calculated show helptext
            conditionalPanel(
              condition = "!input.budget_analysis", 
              helpText(strong("There will be no budget analysis, probably because there is no proper data available."))
            )
            
    ),
    
    # 3.6.2 Top Programs for Budget Analysis ----------------------------------------
    tabItem(tabName = 'budget_top_programs', 
            
            conditionalPanel(
              condition = 'input.budget_analysis', 
              
              # Show top programs by budget needed
              box(
                title = "Top Programs", solidHeader = TRUE, status = 'primary', 
                
                fluidRow(
                  column(
                    3, tags$div(id = "budgetOrder")
                  )
                ),
                
                fluidRow(
                  column(
                    12, dataTableOutput("budget_top_programs")
                  )
                )
              )
            ), 
            
            
            #  Do not show Budget Analysis
            conditionalPanel(
              condition = "!input.budget_analysis",
              helpText(strong("There will be no budget analysis, probably because there is no proper data available."))
            )
    ), 
    
    # 3.6.3 Budget spent per weekday -----------------------
    tabItem(tabName = "budget_per_weekday",
      
      conditionalPanel(
        condition = "input.budget_analysis",
        
        fluidRow(
          # Plot for budget spent per weekday and channel
          box(
            title = "Budget spent per weekday and channel", solidHeader = TRUE, status = 'primary', height = 600,
            
            # see insert_reactive_uis for selection of ordering
            column(
              6, tags$div(id = 'select_top_channels')
            ),
            
            plotOutput("plot_budget_per_weekday")
          ), 
          
          # Budget per Channel table
          box(
            title = "Total budget spent per Channel", solidHeader = TRUE, status = 'primary',
            dataTableOutput("table_budget_per_channel")
          )
        )
      ), 
      #  Do not show Budget Analysis
      conditionalPanel(
        condition = "!input.budget_analysis", 
        helpText(strong("There will be no budget analysis, probably because there is no proper data available."))
      )
    ),
    
    
    
    # 3.7 Powerpoint Export --------------------------------------
    tabItem(tabName = 'ppt_export', 
            box(
              title = 'Export Powerpoint Presentation via Mail', solidHeader = TRUE, status = 'primary', width = 4,
              
              # Download button for ppt and uplift data per channel in xlsx
              fluidRow(
                column(
                  6, downloadButton('out_pptx', 'Download PPT')
                ), 
                column(
                  6, downloadButton('out_xlsx', 'Download Excel')
                )
              )
            
            )
    ), 
    
    
    # Documentation -----------------------------
    tabItem(tabName = 'docu', 
            
            box(
              title = "TV Analysis Documentation", solidHeader = TRUE, status = "primary", 
              
              h4("Technical Documetation: "), 
              
              fluidRow(
                column(
                  3, p("Confluence Page: ")
                ), 
                column(
                  2, p(a("TVex - Confluence", href = "https://confluence.criteois.com/display/TVEX/TV+advertising+performance+analysis"))
                )
              ), 
              fluidRow(
                column(
                  3, p("Gitlab: ")
                ), 
                column(
                  2, p(a("TVex - Git", href = "https://gitlab.criteois.com/ax-analytics/TVex"))
                )
              ), 
              hr(),
              
              h4("Contact: "), 
              
              fluidRow(
                column(
                  5, p("Sonja Metzger, Data Scientist, AX Germany:")
                ), 
                column(
                  2, p(a("Mail", href = "mailto:s.metzger@criteo.com"))
                )
              )
            )
            
    )
  ), 
  
  # Include styles see www folder
  tags$head(tags$link(rel = "stylesheet", type = "text/css", href = "header.css")),
  
  tags$body(tags$link(rel = "stylesheet", type = "text/css", href = "body.css"))
  
  
  
)

# 4. Show interface --------------------------------
dashboardPage(
  header, 
  sidebar, 
  body, 
  skin = "black"
)
