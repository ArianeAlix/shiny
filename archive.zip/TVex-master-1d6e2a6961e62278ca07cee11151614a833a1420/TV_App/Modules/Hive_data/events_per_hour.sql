use aalix;
set mapreduce.job.name='AXTool_TVex';
SET start_date = '2018-12-14';
SET end_date = '2019-02-10';
SET partner_id = 50057;
SET timezone = 'CET';

SET hive.cli.print.header = FALSE;
DROP TABLE IF EXISTS aalix.TV_events;
create table aalix.TV_events as
select 
to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))as day,
hour(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string))as Stunde,
from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as zeitstempel,
 case
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) >= 0 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 30 then 1
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 30 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 60 then 2
else 0 end as split2,
 case
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) >= 0 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 20 then 1
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 20 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 40 then 2
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 40 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 60 then 3
else 0 end as split3,
 case
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) >= 0 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 15 then 1
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 15 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 30 then 2
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 30 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 45 then 3
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 45 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 60 then 4
else 0 end as split4,
 case
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) >= 0 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 12 then 1
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 12 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 24 then 2
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 24 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 36 then 3
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 36 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 48 then 4
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 48 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 60 then 5
else 0 end as split5,
 case
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) >= 0 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 10 then 1
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 10 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 20 then 2
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 20 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 30 then 3
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 30 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 40 then 4
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 40 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 50 then 5
when minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) > 50 and minute(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) <= 60 then 6
else 0 end as split6,
unixtime,
user_id,
transaction_id,
referrer,
event_name,
previous_url
from bi_data.partnerdb_bi_advertiser_event
where to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))>=${hiveconf:start_date} and to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))<=${hiveconf:end_date} and partner_id= ${hiveconf:partner_id} and partner_partition=pmod(${hiveconf:partner_id},1000) and persistent_user=TRUE;

SET hive.cli.print.header = FALSE;
DROP TABLE IF EXISTS aalix.TV_clicks;
create table aalix.TV_clicks as
select 
to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone})) as day,
hour(cast(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as string)) as Stunde,
from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}) as zeitstempel,
unixtime,
user_id,
revenue_euro,
click_cost_euro
from bi_data.partnerdb_bi_click
where to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))>=${hiveconf:start_date} and to_date(from_utc_timestamp(from_unixtime(unixtime),${hiveconf:timezone}))<=${hiveconf:end_date}  and partner_id=${hiveconf:partner_id} and partner_partition=pmod(${hiveconf:partner_id},1000);


SET hive.cli.print.header = TRUE;

Select t1.*, clicks, adv_cost_euro
from
(Select
day,
Stunde,
split2, split3, split4, split5, split6,
min(zeitstempel) as min_zeitstempel,
max(zeitstempel) as max_zeitstempel,
count(distinct user_id) as distinct_user_ids,
count(distinct transaction_id) as transactions,
count(0) as events
from aalix.TV_events
group by day, Stunde, 
split2, split3, split4, split5, split6
) t1
left outer join 
(Select 
day,
Stunde,
count(0) as clicks,
sum(revenue_euro) as adv_cost_euro
from aalix.TV_clicks
group by day, Stunde
) t2
on t1.day=t2.day and t1.Stunde=t2.Stunde
;
