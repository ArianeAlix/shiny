#' Uplift Analysis 
#' 
#' The uplift analysis consists of multiple steps: 
#'     1. Calculate Baseline: 
#'         1.1 Calculate baseline for no tv time as events per hour splits per weekday
#'         1.2 Plot Baseline
#'     2. Calculate Uplift
#'         2.1 Average per hour
#'         2.2 Average per day
#'         2.3 Filter for days with TV spots
#'         2.4 Calculate uplifts
#'     3. Plot Uplifts: 
#'         3.1 Boxplots
#'         3.2 Scatterplots
#'         3.3 Scatterplots with Baseline
#'         3.4 Barcharts
#'         3.5 Output plots in shiny
#' 
#' @param data_all Aggregated data from function \code{data_aggregation()}
#' @param dates_before_spot Last date without TV Spot
#' @param input reactive shiny input
#' @param output reactive output by shiny
#' @return list
#' 
#' @author Conrad Quandel <c.quandel@@criteo.com>
#' @export
#' 

# 1. Calculate Baseline ----------------------
uplift_types <- c("uplift_events", "uplift_transactions")

# Calcluate avg events per hour split per weekday of pre-TV spot period 
react_nospots_avg = reactive({
  
  # First set weekdays and last pre TV time date
  data_all <- react_data_all()
  dates_before_spot <- min(input_mediaplan$Date) - 1
  # dates_before_spot <- as.Date("2018-10-23")
  data_all$dayofweek <- lubridate::wday(data_all$Date, label = TRUE, abbr = FALSE, week_start = 1)
  

  # subset of data before TV spot period
  nospots = subset(data_all, data_all$Date <= dates_before_spot)
  
  # Aggregate over the selected part of the hourf or pre TV time data
  nospots_avg_dayofweek_hour = nospots[,.(
    avg_user = mean(distinct_user_ids),
    avg_transactions = mean(transactions),
    avg_events = mean(events),
    avg_clicks = mean(clicks),
    avg_adv_cost_euro = mean(adv_cost_euro)
  ),
  by = .(dayofweek, Hour, part, hour_split)]
  setorder(nospots_avg_dayofweek_hour, dayofweek, Hour, part)
  
  
  # Calculate reasonable order of MA (around 1 hour) and calculate MAs
  # Depending on the number of splits per hour calculate the order for moving average
  if(!is.null(react_input_hive()$hive_minute)){
    ma_order <- floor(max(nospots_avg_dayofweek_hour$part) / 2 + 1)
  } else {
    ma_order <- floor(max(as.numeric(levels(nospots_avg_dayofweek_hour$part))) / 2 + 1)
  }
  
  # Fill nas: if there are NAs first fill them with the moving average around the events
  na_idx <- which(is.na(nospots_avg_dayofweek_hour$avg_events))
  for(i in na_idx){
    nospots_avg_dayofweek_hour$avg_events[i] = mean(nospots_avg_dayofweek_hour$avg_events[(i - ma_order):(i + ma_order)], na.rm = TRUE)
  }
  
  # Calculate baseline moving averages
  baseline_ma <- nospots_avg_dayofweek_hour[, .(
    avg_user_ma = ma(avg_user, order = ma_order, centre = TRUE),
    avg_transactions_ma = ma(avg_transactions, order = ma_order, centre = TRUE), 
    avg_events_ma = ma(avg_events, order = ma_order, centre = TRUE), 
    avg_clicks_ma = ma(avg_clicks, order = ma_order, centre = TRUE), 
    avg_adv_cost_euro_ma = ma(avg_adv_cost_euro, order = ma_order, centre = TRUE)
  )]

  # Last and first entries of MA cannot be calculated because of order. So we start after
  # Sunday again with Monday and calculate missing baseline MAs
  # NAs are created at the edges of the moving average. This can be avoided, because the week 
  # is cyclical so the NA slots are filled by the end of the week and starting of the week data
  if(ma_order > 1){
    new_base <- rbind(nospots_avg_dayofweek_hour[(nrow(nospots_avg_dayofweek_hour) - floor(ma_order / 2) - ma_order):nrow(nospots_avg_dayofweek_hour)], 
                      nospots_avg_dayofweek_hour[1:(1 + floor(ma_order / 2) + ma_order)])
    baseline_ma[c((nrow(baseline_ma) - (floor(ma_order / 2) - 1)):nrow(baseline_ma), 1:floor(ma_order / 2))] <- 
      as.data.table(
        as.matrix(
          ma(new_base, order = ma_order, centre = TRUE)
        )[(nrow(new_base) / 2 - (floor(ma_order / 2) - 1)):(nrow(new_base) / 2 + floor(ma_order / 2)), 5:9]
      )
  }
  
  # convert time series columns to numeric 
  baseline_ma <- baseline_ma[, lapply(.SD, as.numeric)]
  
  # Bind usual avg events data with moving averages data
  nospots_avg_dayofweek_hour <- cbind(nospots_avg_dayofweek_hour, baseline_ma)
  nospots_avg_dayofweek_hour$part <- factor(nospots_avg_dayofweek_hour$part)
  
  return(nospots_avg_dayofweek_hour)
})




# 1.2 Plot Baseline ------------------------------
output$ref_lines <- renderPlot({
  
  nospots_avg_dayofweek_hour = react_nospots_avg()
  
  # Define selected average coefficient
  selected_average <- input$selectAverage
  if(input$moving_average){
    selected_average <- paste0(selected_average, "_ma")
  }
  
  # As coefficient numbers differs a lot for clients, the y label have to be rounded and set
  # automatically. 
  y_label = seq(
    0, 
    round(max(nospots_avg_dayofweek_hour[[selected_average]], na.rm = TRUE), 
          digits = -(nchar(stri_split_fixed(max(nospots_avg_dayofweek_hour[[selected_average]], 
                                                na.rm = TRUE), ".")[[1]][1]) - 1)), 
                length.out = 5)
  
  # set y axis title 
  y_text = stri_split_regex(selected_average, "_")[[1]]
  y_text = paste( stri_trans_totitle(y_text[2:length(y_text)]), collapse = " ")
  if(stri_detect_regex(y_text, "Adv")){
    y_text = stri_replace_all_regex(y_text, "Adv", "Advertisment")
  }
  
  # delete MA
  if (input$moving_average){
    y_text <- stri_split_fixed(y_text, " Ma")[[1]][1]
  }
  
  # Plot baseline
  plot_ref_lines = ggplot(nospots_avg_dayofweek_hour, aes_string(y = selected_average, x = "hour_split")) +
    geom_line(aes(group = as.factor(dayofweek), color = as.factor(dayofweek))) + 
    labs(x = "Hour", y = paste("Average", y_text), color = "weekday") + 
    scale_color_manual(values = TV_color_theme) + 
    scale_x_continuous(name = "Hour",
                       labels = paste(seq(0, 24, 4)),
                       breaks = seq(0, 24, 4)) +
    scale_y_continuous(
      labels = format(y_label, big.mark = "."),
      breaks = y_label
    ) +
    theme(axis.title = element_text(size = 14), axis.text = element_text(size = 12), 
          legend.title = element_text(size = 14), legend.text = element_text(size = 12))
  
  react_plot_ref_lines(plot_ref_lines)
  plot_ref_lines
  
})

# 2.0 Uplift Calculation -----------------------------
react_uplift_calculation <- reactive({
  
  nospots_avg <- react_nospots_avg()
  
  #get day of week
  data_all <- react_data_all()
  data_all$dayofweek <- lubridate::wday(data_all$Date, label = TRUE, abbr = FALSE, week_start = 1)

  # Merge all data (spots data) with baseline data
  data_uplift <- merge(data_all, nospots_avg, by = c("dayofweek", "Hour", "part", "hour_split"), all.x = TRUE)
  setorder(data_uplift, Date, Hour, part)
  
  # Add average for actual and next element. If the spot is at the end of a split part, the actual events are not 
  # included into uplift. To include this, the average of the split of the spot and the next split is calculated. 
  # This is added as a moving average events to the data
  uplift_cols <- c("events", "clicks", "transactions")
  # Calculate averages
  uplift_ma <- lapply(uplift_cols, function(col){
    col_elements <- data_uplift[[col]]
    out <- rowMeans(cbind(col_elements, c(col_elements[-1], NA)))
    return(out)
  })
  
  # Add to data
  for(i in 1:length(uplift_ma)){
    data_uplift[[paste0(uplift_cols[i], "_ma")]] <- uplift_ma[[i]]
  }
  
  
  # 2.1 sum of weekdays and average per day and hour and part ------------------
  sumday <- data_uplift[,.(
    numb_spots_help1 = max(is.na(Channel)),
    numb_spots_help2 = length(Channel),
    user_s = mean(distinct_user_ids, na.rm = TRUE), 
    user_sm = mean(avg_user, na.rm = TRUE),
    transactions_s = mean(transactions, na.rm = TRUE), 
    transactions_sm = mean(avg_transactions, na.rm = TRUE),
    events_s = mean(events, na.rm = TRUE), 
    events_sm = mean(avg_events, na.rm = TRUE),
    clicks_s = mean(clicks, na.rm = TRUE), 
    clicks_sm = mean(avg_clicks, na.rm = TRUE),            
    adv_cost_euro_s = mean(adv_cost_euro, na.rm = TRUE), 
    adv_cost_euro_sm = mean(avg_adv_cost_euro, na.rm = TRUE)),
    by = .(Date, Hour, part, hour_split)]
  
  sumday$numb_spots <- ifelse(sumday$numb_spots_help1 == 1, 0, sumday$numb_spots_help2)
  sumday$numb_spots_help1 <- NULL
  sumday$numb_spots_help2 <- NULL
  
  
  # 2.2 sum of weekdays and average per day -----------------------------
  sumday2 <- sumday[, .(
    user_s = sum(user_s, na.rm = TRUE), 
    user_sm = sum(user_sm, na.rm = TRUE),
    transactions_s = sum(transactions_s, na.rm = TRUE), 
    transactions_sm = sum(transactions_sm, na.rm = TRUE),
    events_s = sum(events_s, na.rm = TRUE), 
    events_sm = sum(events_sm, na.rm = TRUE),
    clicks_s = sum(clicks_s, na.rm = TRUE), 
    clicks_sm = sum(clicks_sm, na.rm = TRUE),            
    adv_cost_euro_s = sum(adv_cost_euro_s, na.rm = TRUE), 
    adv_cost_euro_sm = sum(adv_cost_euro_sm, na.rm = TRUE)),
    by = .(Date)]
  setorder(sumday2, Date)
  
  # merge uplift data with averages per day
  data_uplift2 = merge(data_uplift, sumday2, by = "Date")
  
  # 2.3 filter on days only with TV ------------------------------
  data_uplift2 = subset(data_uplift2, is.na(data_uplift2$Hour) == FALSE & is.na(data_uplift2$Channel) == FALSE)
  
  # 2.4 Compute uplift, normed by total numbers events per day ------------------------------
  data_uplift2$uplift_events = ((data_uplift2$events / data_uplift2$events_s) / 
                                  (data_uplift2$avg_events / data_uplift2$events_sm)) - 1
  data_uplift2$uplift_clicks = ((data_uplift2$clicks / data_uplift2$clicks_s) / 
                                  (data_uplift2$avg_clicks / data_uplift2$clicks_sm)) - 1
  data_uplift2$uplift_transactions = ((data_uplift2$transactions / data_uplift2$transactions_s) / 
                                        (data_uplift2$avg_transactions / data_uplift2$transactions_sm)) - 1
  
  # Uplift with MA
  data_uplift2$uplift_events_ma = ((as.numeric(data_uplift2$events_ma) / data_uplift2$events_s) / 
                                  (data_uplift2$avg_events_ma / data_uplift2$events_sm)) - 1
  data_uplift2$uplift_clicks_ma = ((as.numeric(data_uplift2$clicks_ma) / data_uplift2$clicks_s) / 
                                  (data_uplift2$avg_clicks_ma / data_uplift2$clicks_sm)) - 1
  data_uplift2$uplift_transactions_ma = ((as.numeric(data_uplift2$transactions_ma) / data_uplift2$transactions_s) / 
                                        (data_uplift2$avg_transactions_ma / data_uplift2$transactions_sm)) - 1
  
  # uplift smaller than zero to zero
  # An uplift of smaller than zero, so an negative uplift, is not affected by an TV spot, 
  # it makes sense to set the uplift to 0. So the assumption is, that a spot can either 
  # have a positive uplift or none, but not negative. 
  data_uplift2[uplift_events <= 0, uplift_events := 0]
  data_uplift2[uplift_events_ma <= 0, uplift_events_ma := 0]
  data_uplift2[uplift_clicks <= 0, uplift_clicks := 0]
  data_uplift2[uplift_clicks_ma <= 0, uplift_clicks_ma := 0]
  data_uplift2[uplift_transactions <= 0, uplift_transactions := 0]
  data_uplift2[uplift_transactions_ma <= 0, uplift_transactions_ma := 0]
  
  # Uplift points are calculated as the avg events in that split + the uplift percentage * the average events. 
  # This is used for the scatterplots.
  data_uplift2$uplift_point_events = data_uplift2$avg_events + data_uplift2$uplift_events * data_uplift2$avg_events
  data_uplift2$uplift_point_clicks = data_uplift2$avg_clicks + data_uplift2$uplift_clicks * data_uplift2$avg_clicks
  data_uplift2$uplift_point_transactions = data_uplift2$avg_transactions+  data_uplift2$uplift_transactions * data_uplift2$avg_transactions
  
  # also for Moving Average
  data_uplift2$uplift_point_events_ma = data_uplift2$avg_events_ma + data_uplift2$uplift_events_ma * data_uplift2$avg_events_ma
  data_uplift2$uplift_point_clicks_ma = data_uplift2$avg_clicks_ma + data_uplift2$uplift_clicks_ma * data_uplift2$avg_clicks_ma
  data_uplift2$uplift_point_transactions_ma = data_uplift2$avg_transactions_ma + data_uplift2$uplift_transactions_ma * data_uplift2$avg_transactions_ma
  
  # Change infinite values to NAs
  for(cols in colnames(data_uplift2)[grep('uplift', colnames(data_uplift2))]){
    data_uplift2[[cols]][is.infinite(data_uplift2[[cols]])] <- NA
  }
  
  # Add month to data to make data more visualizable
  data_uplift2$month <- format(data_uplift2$Date, "%B")
  
  return(data_uplift2)
  
})


# 3 Graphs for Uplift ---------------------------------

# Some setups of the uplift data for plots

# calculate number of spots per channel
react_channel_spots <- reactive({
  
  input_mediaplan <- as.data.table(react_input_mediaplan())
  channel_spots <- input_mediaplan[, .(sum_spots = length(Program)), by = .(Channel)] %>%
    setorderv("sum_spots", order = -1)
  
})

# Set up data 
react_plot_uplift_data <- reactive({
  
  data_uplift2 = react_uplift_calculation()
  channel_spots <- react_channel_spots()
  
  # Select channel spots by either selecting number of channels or selecting rows in DT table.
  if(length(input$channel_spots_rows_selected) == 0){
    channel_spots <- channel_spots[1:input$select_channels]
  } else {
    channel_spots <- channel_spots[input$channel_spots_rows_selected]
  }
  
  # subset uplift data by selected channels
  data_uplift3 <- subset(data_uplift2, data_uplift2$Channel %in% channel_spots$Channel)
  
  # Split data by months and add all data if there is more than one month
  split_by_month <- split(data_uplift3, by = "month")
  if(length(unique(data_uplift3$month)) > 1){
    split_by_month$All <- data_uplift3
    split_by_month <- split_by_month[c("All", names(split_by_month)[-which(names(split_by_month) == "All")])]
  }
  
  return(split_by_month)
  
})



# 3.1 Boxplot Uplift -----------------
react_plot_uplift_boxplot <- reactive({
  
  split_by_month <- react_plot_uplift_data()
  
  # Adjust point size. 
  if(length(input$channel_spots_rows_selected) == 0){
    point.size <- 2 / input$select_channels * 10
  } else {
    point.size <- 2 / length(input$channel_spots_rows_selected) * 10
  }
  
  
  # Calculate uplift per channel for all different months and uplift types.
  # Loop over uplift types (events, clicks, transactions)
  plot_uplift_channel <- lapply(1:length(uplift_types), function(i){
    
    # loop over months (all, and unique other)
    per_month <- lapply(1:length(split_by_month), function(j){
      
      # select month data and weekdays
      month_data = split_by_month[[j]]
      unique_weekdays = c("All", unique(as.character(month_data$dayofweek)))  
      
      # Loop over weekdays
      per_weekday <- lapply(1:length(unique_weekdays), function(k){
        
        # Points with budget over defined percentage are drawn, the rest is filtered out
        # if budget analysis is possible
        if(input$budget_analysis){
          index_filter_data_points <- 
            which(month_data[, eval(parse(text = input$budget_column))] >= 
                    month_data[, quantile(eval(parse(text = input$budget_column)), 
                                                   input$uplift_percentage_of_points / 100)])
        } else {
          index_filter_data_points <- 1:nrow(month_data)
        }
        
        # use moving average for uplift calc
        if(input$moving_average){
          y_uplift <- paste0(uplift_types[i], "_ma")
        } else {
          y_uplift <- uplift_types[i]
        }
        
        
        # filter for weekday
        if(unique_weekdays[k] == "All"){
          plot_data <- month_data
        } else {
          plot_data <- month_data[unique_weekdays[k], on = .(dayofweek)]
        }
        
        # Plot boxplots
        g2_month <- ggplot(data = plot_data, aes(x = Channel, y = eval(parse(text = y_uplift))))
        plot_out <- g2_month + geom_boxplot(fill = "grey", colour = "darkgrey", alpha = 0.3) +
          theme_bw() + 
          theme(axis.text = element_text(size = 12), axis.title = element_text(size = 14)) +
          coord_flip() + 
          geom_hline(aes(yintercept = 0), colour = "red", size = 1) +
          ylab(stri_trans_totitle(str_replace(uplift_types[i], "_", " "))) + 
          geom_point(data = plot_data[index_filter_data_points], 
                     aes(x = Channel, y = eval(parse(text = y_uplift)), 
                         colour = Hour, group = Hour), 
                     size = point.size)
        
        return(plot_out)
        
      })
      names(per_weekday) <- unique_weekdays
      return(per_weekday)
      
    })
    names(per_month) <- names(split_by_month)
    return(per_month)
    
  })
  names(plot_uplift_channel) <- uplift_types 
  
  return(plot_uplift_channel)
  
})

# 3.2 Scatterplot of uplift ---------------
react_plot_uplift_scatter <- reactive({
  
  split_by_month <- react_plot_uplift_data()
  
  # Calculate uplift per channel for all different months and uplift types. 
  # Loop over uplift types (events, clicks, transactions)
  plot_uplift_channel <- lapply(1:length(uplift_types), function(i){
    
    # Loop over months (All, other)
    per_month <- lapply(1:length(split_by_month), function(j){
      
      # select month data and possible weekdays
      month_data = split_by_month[[j]]
      unique_weekdays = c("All", unique(as.character(month_data$dayofweek)))  
      
      # Loop over weekdays (all, other)
      per_weekday <- lapply(1:length(unique_weekdays), function(k){
        
        
        # Points with budget over defined percentage are drawn, the rest is filtered out
        # if budget analysis is possible
        if(input$budget_analysis){
          index_filter_data_points <- 
            which(month_data[, eval(parse(text = input$budget_column))] >= 
                    month_data[, quantile(eval(parse(text = input$budget_column)), 
                                                   input$uplift_percentage_of_points / 100)])
        } else {
          index_filter_data_points <- 1:nrow(month_data)
        }
        
        # use moving average for uplift calc
        if(input$moving_average){
          y_uplift <- paste0(uplift_types[i], "_ma")
        } else {
          y_uplift <- uplift_types[i]
        }
        
        
        # filter for weekday
        if(unique_weekdays[k] == "All"){
          plot_data <- month_data
        } else {
          plot_data <- month_data[unique_weekdays[k], on = .(dayofweek)]
        }
        
        # edit time as numeric value
        plot_data$Time_edit <- hms(plot_data$Time)
        plot_data$Time_edit <- lubridate::hour(plot_data$Time_edit) + round(lubridate::minute(plot_data$Time_edit) / 60, digit = 2)
        plot_data[[y_uplift]][plot_data[[y_uplift]] < 0] <- 0
        
        # Plot uplift points 
        plot_out <- ggplot(data = plot_data, aes(x = Time_edit, y = eval(parse(text = y_uplift)))) + 
          geom_point(aes(colour = Channel), size = 2.5) + 
          scale_color_manual(values = TV_color_theme) + 
          theme_bw() + 
          theme(axis.text = element_text(size = 12), axis.title = element_text(size = 14)) + 
          ylab(stri_trans_totitle(paste("total", stri_split_regex(uplift_types[i], "_")[[1]][2]))) +
          scale_x_continuous(
            breaks = seq(0, 24, 4),
            limits = c(0, 24)) + 
          ylim(0, max(data_uplift2[[y_uplift]])) 
        
        return(plot_out)
        
      })
      names(per_weekday) <- unique_weekdays
      return(per_weekday)
      
    })
    
    names(per_month) <- names(split_by_month)
    return(per_month)
    
  })
  names(plot_uplift_channel) <- uplift_types 
  
  return(plot_uplift_channel)
  
})


# 3.3 Baseline Uplift -------------
react_plot_uplift_baseline <- reactive({
  
  baseline = react_nospots_avg()
  split_by_month = react_plot_uplift_data()
  
  # Aggregate Baseline for selected weekday
  type_of_uplift = stri_split_regex(input$selectUplift, "_")[[1]][2]
  if(input$moving_average){
    type_of_uplift = paste0(type_of_uplift, "_ma")
  }
  
  # Calculate uplift per channel for all different months and uplift types. 
  # Loop over uplift types (events, clicks, transactions)
  plot_uplift_channel <- lapply(1:length(uplift_types), function(i){
    
    # Loop over different months and all months merged
    per_month <- lapply(1:length(split_by_month), function(j){
      
      # Select month data
      month_data = split_by_month[[j]]
      unique_weekdays = c("All", unique(as.character(month_data$dayofweek)))
      
      # loop over unique weekdays
      per_weekday <- lapply(1:length(unique_weekdays), function(k){
        
        
        # Points with budget over defined percentage are drawn, the rest is filtered out
        # if budget analysis is possible
        if(input$budget_analysis){
          index_filter_data_points <- 
            which(month_data[, eval(parse(text = input$budget_column))] >= 
                    month_data[, quantile(eval(parse(text = input$budget_column)), 
                                          input$uplift_percentage_of_points / 100)])
        } else {
          index_filter_data_points <- 1:nrow(month_data)
        }
        
        # use moving average for uplift calc
        if(input$moving_average){
          y_uplift <- paste0(uplift_types[i], "_ma")
        } else {
          y_uplift <- uplift_types[i]
        }
        
        # filter for weekday
        if(unique_weekdays[k] == "All"){
          plot_data <- month_data
        } else {
          plot_data <- month_data[unique_weekdays[k], on = .(dayofweek)]
        }
        
        # all weekdays are used the actual baseline per weekday has to be averaged again and 
        # the uplift points are calcuated again as well as the baseline has changed
        if(unique_weekdays[k] == "All"){
          
          # Calculate baseline either by ma or not
          baseline_cols <- paste0("avg_", c("events", "clicks", "transactions"))
          if(input$moving_average){
            baseline_weekday = baseline[, .(
              avg_events_ma = mean(avg_events_ma, na.rm = TRUE),
              avg_clicks_ma = mean(avg_clicks_ma, na.rm = TRUE),
              avg_transactions_ma = mean(avg_transactions_ma, na.rm = TRUE)
            ), by = .(Hour, part, hour_split)]
            baseline_cols <- paste0(baseline_cols, "_ma")
          } else {
            baseline_weekday = baseline[, .(
              avg_events = mean(avg_events, na.rm = TRUE),
              avg_clicks = mean(avg_clicks, na.rm = TRUE),
              avg_transactions = mean(avg_transactions, na.rm = TRUE)
            ), by = .(Hour, part, hour_split)]
          }
          
          # uplift data
          plot_data_weekday = plot_data
          test = merge(plot_data_weekday[, .SD, .SDcols = -baseline_cols], 
                       baseline_weekday, 
                       by = c("Hour", "part", "hour_split"), 
                       all.x = TRUE)
          test[[paste0("uplift_point_", type_of_uplift)]] = test[[paste0("avg_", type_of_uplift)]] + 
            ifelse(test[[y_uplift]] > 0, test[[y_uplift]], 0) * test[[paste0("avg_", type_of_uplift)]]
          plot_data_weekday = test
        } else {
          
          # For single weekdays the uplift points does not have to be calculated again.
          # Calculate baseline by ma or not
          if(input$moving_average){
            baseline_weekday = baseline[unique_weekdays[k] == dayofweek, .(
              avg_events_ma = mean(avg_events_ma, na.rm = TRUE),
              avg_clicks_ma = mean(avg_clicks_ma, na.rm = TRUE),
              avg_transactions_ma = mean(avg_transactions_ma, na.rm = TRUE)
            ), by = .(Hour, part, hour_split)]
          } else {
            baseline_weekday = baseline[unique_weekdays[k] == dayofweek, .(
              avg_events = mean(avg_events, na.rm = TRUE),
              avg_clicks = mean(avg_clicks, na.rm = TRUE),
              avg_transactions = mean(avg_transactions, na.rm = TRUE)
            ), by = .(Hour, part, hour_split)]
          }
          
          # uplift data
          plot_data_weekday = plot_data
          
        }
        
        # set y labels
        y_label = seq(
          0, 
          round(max(plot_data_weekday[[paste0("uplift_point_", type_of_uplift)]], na.rm = TRUE), 
                digits = -(nchar(stri_split_fixed(max(plot_data_weekday[[paste0("uplift_point_", type_of_uplift)]], na.rm = TRUE), 
                                                  ".")[[1]][1]) - 2)), 
          length.out = 5
        )
        
        # Caclulate correct time edit as numeric number
        plot_data_weekday$Time_edit <- hms(plot_data_weekday$Time)
        plot_data_weekday$Time_edit <- lubridate::hour(plot_data_weekday$Time_edit) + round(lubridate::minute(plot_data_weekday$Time_edit) / 60, digit = 2)
        
        
        # plot uplift points
        plot_out = ggplot(data = plot_data_weekday, 
                          aes(x = Time_edit, y = eval(parse(text = paste0("uplift_point_", type_of_uplift))), 
                              colour = Channel)) + 
          geom_point(size = 2.5) + 
          scale_color_manual(values = TV_color_theme) +
          labs(x = "Hour", y = stri_trans_totitle(paste("total", stri_split_regex(uplift_types[i], "_")[[1]][2]))) + 
          scale_x_continuous(
            name = "Hour",
            labels = paste(seq(0, 24, 4)),
            breaks = seq(0, 24, 4)
          ) +
          scale_y_continuous(
            labels = format(y_label, big.mark = "."),
            breaks = y_label
          ) +
          theme(
            axis.title = element_text(size = 14), 
            axis.text = element_text(size = 12),
            legend.title = element_blank(), 
            legend.text = element_text(size = 10)
          ) + 
          # Add baseline
          geom_line(
            data = baseline_weekday, 
            aes(x = hour_split, y = eval(parse(text = paste0("avg_", type_of_uplift)))), 
            colour = "#54585a", size = 1
          )
        
        plot_out
        return(plot_out)
        
      })
      names(per_weekday) <- unique_weekdays
      return(per_weekday)
      
    })
    
    names(per_month) <- names(split_by_month)
    return(per_month)
    
  })
  names(plot_uplift_channel) <- uplift_types 
  
  return(plot_uplift_channel)
  
  
})


# 3.4 Bar Charts Uplift per Channel --------------
react_plot_uplift_barchart <- reactive({
  
  split_by_month <- react_plot_uplift_data()
  
  # Calculate uplift per channel for all different months and uplift types. 
  # Loop over uplift types (events, clicks, transactions)
  plot_uplift_channel <- lapply(1:length(uplift_types), function(i){
    
    # Loop over months (all, other)
    per_month <- lapply(1:length(split_by_month), function(j){
      
      # select month data and unique weekdays
      month_data = split_by_month[[j]]
      unique_weekdays = c("All", unique(as.character(month_data$dayofweek)))  
      
      # Loop over weekdays (all, other)
      per_weekday <- lapply(1:length(unique_weekdays), function(k){
        
        # use moving average for uplift calc
        if(input$moving_average){
          y_uplift <- paste0(uplift_types[i], "_ma")
        } else {
          y_uplift <- uplift_types[i]
        }
        
        # filter for weekday and average uplift per channel
        if(unique_weekdays[k] == "All"){
          barplot_data = month_data[, .(
            avg_uplift = mean(eval(parse(text = y_uplift)), na.rm = TRUE)
          ), by = .(Channel)] 
        } else {
          plot_data <- month_data[unique_weekdays[k], on = .(dayofweek)]
          barplot_data = plot_data[, .(
            avg_uplift = mean(eval(parse(text = y_uplift)), na.rm = TRUE)
          ), by = .(Channel)]
        }
        setorderv(barplot_data, "avg_uplift", -1)
        
        # Change Channel labels so that every second Channel is linebreaked
        x_labels <- as.character(barplot_data$Channel)
        if(any(nchar(x_labels) > 15)){
          for(lab in 1:length(x_labels)){
            if(nchar(x_labels[lab]) > 15){
              x_labels[lab] <- stri_replace_last_fixed(x_labels[lab], " ", "\n")
            }
          }
        }
        
        # visualise plots
        plot_out <- ggplot(data = barplot_data, aes(x = reorder(Channel, -avg_uplift), y = avg_uplift)) + 
          geom_bar(stat = "identity", fill = "#F78B2C") + 
          labs(y = "Mean Uplift", x = "Channels") + 
          theme_criteo_default(base_size = 2) + 
          theme(
            axis.title = element_text(size = 12), 
            axis.text.x = element_text(
              size = 14, angle = 45, hjust = 1
            ), 
            legend.position = "none"
          ) + 
          scale_x_discrete(labels = x_labels) 
        
        
        return(plot_out)
        
      })
      names(per_weekday) <- unique_weekdays
      return(per_weekday)
      
    })
    names(per_month) <- names(split_by_month)
    return(per_month)
    
  })
  names(plot_uplift_channel) <- uplift_types 
  
  return(plot_uplift_channel)
  
})


# 3.5 Output uplift plot -------------------
output$uplift_per_channel = renderPlot({
  
  # select plot by uplift type, month and weekday as well as plot type
  if(input$plot_type == "Boxplot"){
    return(react_plot_uplift_boxplot()[[input$selectUplift]][[input$selectMonth]][[input$selectWeekday]])
  }
  
  if(input$plot_type == "Scatterplot"){
    return(react_plot_uplift_scatter()[[input$selectUplift]][[input$selectMonth]][[input$selectWeekday]])
  }
  
  if(input$plot_type == "Scatterplot with Baseline"){
    return(react_plot_uplift_baseline()[[input$selectUplift]][[input$selectMonth]][[input$selectWeekday]])
  }
  
  if(input$plot_type == "Barchart"){
    return(react_plot_uplift_barchart()[[input$selectUplift]][[input$selectMonth]][[input$selectWeekday]])
  }
  
})

