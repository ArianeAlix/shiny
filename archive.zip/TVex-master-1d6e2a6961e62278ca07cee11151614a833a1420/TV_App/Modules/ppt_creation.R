#' Creation of Powerpoint Slides
#' 

inc_nr <- length(grep("ppt_include", names(input)))
char_factor <- 0.15

# Initiating Slides ------------------
mydoc <- read_pptx(path = "Presentations/PPT_Template_TVAPP.pptx")
lp <- layout_properties(mydoc, layout = 'Custom Layout')
mydoc <- add_slide(mydoc, layout = "Custom Layout", master = "CriteoPowerpointTheme") %>%
  ph_with_text(str = input$advertiser_name) %>%
  ph_with_text(str = 'TV Campaign Analysis', index = which(lp$ph_label == 'Name'), type = 'body') %>%
  ph_with_text(str = format(Sys.Date(), format = '%d.%m.%Y'), index = which(lp$ph_label == 'Date'), type = 'body')



# Aggregation plots -----------------------
# Total Plots
# browser()
if(input$ppt_include_aggr_total){
  
  plot_aggr_total <- react_plot_aggr_total()
  
  lp <- layout_properties(mydoc, layout = 'Blank Slide')
  mydoc <- add_slide(mydoc, layout = 'Blank Slide', master = 'CriteoPowerpointTheme') %>%
    ph_with_text(str = paste("Total", input$coeff, "aggregated per day")) %>%
    ph_with_gg(value = plot_aggr_total, type = 'body', index = which(lp$ph_label == "PH"))
  
}

# Ratio for spots and events per day
if(input$ppt_include_aggr_ratio){
  
  plot_aggr_ratio <- react_plot_aggr_ratio()
  
  lp <- layout_properties(mydoc, layout = 'Blank Slide')
  mydoc <- add_slide(mydoc, layout = 'Blank Slide', master = 'CriteoPowerpointTheme') %>%
    ph_with_text(str = paste('Ratio of spots and', input$coeff, 'per day')) %>%
    ph_with_gg(value = plot_aggr_ratio, type = 'body', index = which(lp$ph_label == "PH"))
  
}

# Reference lines no TV time
if(input$ppt_include_preTV){
  
  plot_ref_lines <- react_plot_ref_lines()
  
  lp <- layout_properties(mydoc, layout = 'Blank Slide')
  mydoc <- add_slide(mydoc, layout = 'Blank Slide', master = 'CriteoPowerpointTheme') %>%
    ph_with_text(str = "Reference Lines per Weekday: No TV time") %>%
    ph_with_gg(value = plot_ref_lines, type = 'body', index = which(lp$ph_label == "PH"))
  
}
incProgress(amount = 1 / inc_nr, detail = "Initiate Powerpoint and pre TV Analysis done")


# Uplift Analysis per Month ----------------------
# Plot only if there is at least one uplift type selected.
if(length(input$uplift_settings) > 0){
  
  for(ppt_type in input$ppt_plots){
    # select of which uplift plot is chosen
    if(ppt_type == "Boxplot"){
      plot_uplift_channel <- react_plot_uplift_boxplot()
    }
    if(ppt_type == "Scatterplot"){
      plot_uplift_channel <- react_plot_uplift_scatter()
    }
    if(ppt_type == "Scatterplot with Baseline"){
      plot_uplift_channel <- react_plot_uplift_baseline()
    }
    if(ppt_type == "Barchart"){
      plot_uplift_channel <- react_plot_uplift_barchart()
    }
    
    # Reordering: All data at first place if there exist more than one month.
    if(length(plot_uplift_channel[[1]]) > 1){
      
      for(i in 1:length(plot_uplift_channel)){
        plot_uplift_channel[[i]] <- 
          plot_uplift_channel[[i]][c("All", names(plot_uplift_channel[[i]])[-which(names(plot_uplift_channel[[i]]) == "All")])]
        
      }
      
    }
    
    # If there are more than one selected type, plot two types on one side
    if(length(input$uplift_settings) > 1){
      
      # Select plots with selected types
      current_plot_type <- plot_uplift_channel[input$uplift_settings]
      
      # boolean if weekdays should be included into ppt. IF not, then 
      # select only the plots labeled with all
      if(!input$ppt_include_weekdays){
        
        plot_out <- lapply(input$uplift_settings, function(type){
          out <- lapply(names(current_plot_type[[type]]), function(months){
            current_plot_type[[type]][[months]]["All"]
          })
          names(out) <- names(current_plot_type[[type]])
          return(out)
        })
        names(plot_out) <- input$uplift_settings
        current_plot_type <- plot_out
        
      }
      
      # browser()
      # Run loop over all months
      for(j in 1:length(current_plot_type[[1]])){
        
        # loop over all weekdays
        for(k in 1:length(current_plot_type[[1]][[j]])){
          
          # Adjust title to if different weekdays are included. 
          if(!input$ppt_include_weekdays){
            ppt_title <- paste0("Uplift Analysis for month: ", names(current_plot_type[[1]])[j])
          } else {
            ppt_title <- paste0("Uplift Analysis for month: ", names(current_plot_type[[1]])[j], 
                                "; weekday: ", names(current_plot_type[[1]][[j]])[k])
          }
          
          
          # Add two plot slide for first two uplift types
          lp <- layout_properties(mydoc, layout = 'twoPlot_withTitles')
          idx_1 <- which(lp$ph_label == 'Plot Title 1')
          idx_2 <- which(lp$ph_label == 'Plot Title 2')
          plot_title_1 <- paste( stri_trans_totitle( stri_split_regex(input$uplift_settings[1], "_")[[1]][2] ) )
          plot_title_2 <- paste( stri_trans_totitle( stri_split_regex(input$uplift_settings[2], "_")[[1]][2] ) )
          mydoc <- add_slide(mydoc, layout = 'twoPlot_withTitles', master = 'CriteoPowerpointTheme') %>%
            ph_with_text(str = ppt_title) %>%
            ph_with_fpars_at(fpars = list(fpar(ftext(plot_title_1, shortcuts$fp_bold(font.family = 'Century Gothic', font.size = 14)))), 
                             fp_pars = list(fp_par(text.align = 'center')),
                             left = lp$offx[idx_1] - lp$cy[idx_1] / 2 + lp$cx[idx_1] / 2, 
                             top = lp$offy[idx_1] + lp$cy[idx_1] / 2 - lp$cx[idx_1] / 2, 
                             width = lp$cy[idx_1], height = lp$cx[idx_1], rot = 90) %>%
            ph_with_fpars_at(fpars = list(fpar(ftext(plot_title_2, shortcuts$fp_bold(font.family = 'Century Gothic', font.size = 14)))), 
                             fp_pars = list(fp_par(text.align = 'center')),
                             left = lp$offx[idx_2] - lp$cy[idx_2] / 2 + lp$cx[idx_2] / 2, 
                             top = lp$offy[idx_2] + lp$cy[idx_2] / 2 - lp$cx[idx_2] / 2, 
                             width = lp$cy[idx_2], height = lp$cx[idx_2], rot = 90) %>%
            ph_with_gg(value = current_plot_type[[1]][[j]][[k]], type = 'body', index = which(lp$ph_label == 'Plot 1')) %>%
            ph_with_gg(value = current_plot_type[[2]][[j]][[k]], type = 'body', index = which(lp$ph_label == 'Plot 2'))
            
          
          
          # if there are 3 selected uplift types, add another slide with third type.
          if(length(current_plot_type) == 3){
            
            lp <- layout_properties(mydoc, layout = 'singlePlot_withTitles')
            idx <- which(lp$ph_label == 'Plot Title')
            plot_title <- paste( stri_trans_totitle( stri_split_regex(input$uplift_settings[3], "_")[[1]][2] ) )
            mydoc <- add_slide(mydoc, layout = 'singlePlot_withTitles', master = 'CriteoPowerpointTheme') %>%
              ph_with_text(str = ppt_title) %>% 
              ph_with_fpars_at(fpars = list(fpar(ftext(plot_title, shortcuts$fp_bold(font.family = 'Century Gothic', font.size = 14)))), 
                               fp_pars = list(fp_par(text.align = 'center')),
                               left = lp$offx[idx] - lp$cy[idx] / 2 + lp$cx[idx] / 2, 
                               top = lp$offy[idx] + lp$cy[idx] / 2 - lp$cx[idx] / 2, 
                               width = lp$cy[idx], height = lp$cx[idx], rot = 90) %>%
              ph_with_gg(value = current_plot_type[[3]][[j]][[k]], type = 'body', index = which(lp$ph_label == 'Plot'))
            
          }
          
        }
      }
      
    } else {
      
      current_plot_type <- plot_uplift_channel[[input$uplift_settings]]
      # If only one type is selected
      
      # Select only all Data for a month and not splitted by weekday. 
      if(!input$ppt_include_weekdays){
        
        month_names <- names(current_plot_type)
        current_plot_type <- lapply(names(current_plot_type), function(months){
          current_plot_type[[months]]["All"]
        })
        names(current_plot_type) <- month_names
        
      }
      
      # Loop over Months
      for(j in 1:length(current_plot_type)){
        
        plot_data <- current_plot_type[[j]]
        
        # Loop over weekdays
        for(k in 1:length(plot_data)){
          
          # Adjust title to if different weekdays are included. 
          if(!input$ppt_include_weekdays){
            ppt_title <- paste0("Uplift Analysis for month: ", names(current_plot_type)[j])
          } else {
            ppt_title <- paste0("Uplift Analysis for month: ", names(current_plot_type)[j], "; weekday: ", names(plot_data)[k])
          }
          
          # Print plots for all months for selected type
          lp <- layout_properties(mydoc, layout = 'singlePlot_withTitles')
          idx <- which(lp$ph_label == 'Plot Title')
          plot_title <- paste( stri_trans_totitle( stri_split_regex(input$uplift_settings[1], "_")[[1]][2] ) )
          mydoc <- add_slide(mydoc, layout = 'singlePlot_withTitles', master = 'CriteoPowerpointTheme') %>%
            ph_with_text(str = ppt_title) %>% 
            ph_with_fpars_at(fpars = list(fpar(ftext(plot_title, shortcuts$fp_bold(font.family = 'Century Gothic', font.size = 14)))), 
                             fp_pars = list(fp_par(text.align = 'center')),
                             left = lp$offx[idx] - lp$cy[idx] / 2 + lp$cx[idx] / 2, 
                             top = lp$offy[idx] + lp$cy[idx] / 2 - lp$cx[idx] / 2, 
                             width = lp$cy[idx], height = lp$cx[idx], rot = 90) %>%
            ph_with_gg(value = plot_data[[k]], type = 'body', index = which(lp$ph_label == 'Plot'))
        }
      }
      
    }
  }
  
  
}
incProgress(1 / inc_nr, detail = "Uplift Analysis done")


# Top perfroming programs ---------------------------
if(input$ppt_include_top20){
  
  # Set up top 20 programs for ppt
  top_20_Program <- react_top_programs()
  
  for(channel in names(top_20_Program)){
    
    current_channel = top_20_Program[[channel]]
    max_row <- ifelse(nrow(current_channel) > 16, 16, nrow(current_channel))
    
    top_20_Program_ftable <- flextable(current_channel[c(1:max_row), ]) %>%
      width(width = c(5, 1.5, 1.3, 1.3)) %>%
      fontsize(part = 'header', size = 12) %>%
      fontsize(part = 'body', size = 10) %>%
      font(part = 'all', fontname = 'Century Gothic') %>%
      bold(part = 'header') %>%
      padding(part = 'header', padding.left = 3, padding.right = 3, padding.bottom = 2, padding.top = 2) %>%
      padding(part = 'body', padding.left = 2, padding.right = 2, padding.bottom = 1, padding.top = 1) %>%
      bg(i = seq(from = 1, to = max_row, by = 2), bg = "gray95") %>%
      border_inner_h(border = fp_border(style = 'solid', color = 'gray')) %>%
      border_inner_v(border = fp_border(style = 'solid', color = 'gray')) %>%
      border_outer(part = 'all', border = fp_border(color = 'gray')) %>%
      set_header_labels(sum_uplift = 'sum uplift', numb_spots = 'number spots') 
    
    
    # Add top programs flex table to slides
    lp <- layout_properties(mydoc, layout = "Data(Chart)")
    mydoc <- add_slide(mydoc, layout = "Data(Chart)", master = "CriteoPowerpointTheme") %>%
      ph_with_text(paste("Top performing Programs (events uplift) of channel", channel)) %>%
      ph_with_flextable(value = top_20_Program_ftable, index = which(lp$ph_label == 'table'))
    
  }
  
  
}


# Barplot for Uplift per Program per Channel --------------------
if(input$ppt_includ_barplotUplift){
  
  channel_uplift_barplots <- react_barchart_uplift_data()
  
  for(channel in names(channel_uplift_barplots)){
    
   lp <- layout_properties(mydoc, layout = "Blank Slide")
    mydoc <- add_slide(mydoc, layout = 'Blank Slide', master = "CriteoPowerpointTheme") %>%
      ph_with_text(paste0("Uplift Report by Program for Channel: ", channel)) %>%
      ph_with_gg(value = channel_uplift_barplots[[channel]], index = which(lp$ph_label == 'PH'))
      
    
  }
  
}


# browser()
# Extreme performing programs --------------
if(input$ppt_include_extreme_uplift){
  
  uplift_col <- react_uplift_col()
  
  for(channel in names(react_table_extreme_uplift())){
    
    table_extreme_uplift <- react_table_extreme_uplift()[[channel]]
    table_extreme_uplift <- table_extreme_uplift[, c("Date", "dayofweek", "Time", "Channel", "Program", uplift_col), with = FALSE]
    split_f <- (table_extreme_uplift[[uplift_col]] > 0) * 1
    split_extreme <- split(table_extreme_uplift, split_f)
    
    # filter for proper number of entries
    top_lower_extreme <- lapply(1:length(split_extreme), function(i){
      table_extreme <- split_extreme[[i]]
      ifelse(all(table_extreme[[react_uplift_col()]] > 0),
             setorderv(table_extreme, react_uplift_col(), order = -1),
             setorderv(table_extreme, react_uplift_col(), order = 1))
      
      if(nrow(table_extreme) > 8){
        table_extreme <- table_extreme[1:8]
      }
      table_extreme[[react_uplift_col()]] <- round(table_extreme[[react_uplift_col()]], digits = 3)
      
      colnames(table_extreme)[6] <- "Uplift"
      flextable(table_extreme) %>%
        width(width = c(1, 1.3, 1, 1.2, 3, 0.8)) %>%
        fontsize(part = 'header', size = 12) %>%
        font(part = 'all', fontname = 'Century Gothic') %>%
        bold(part = 'header') %>%
        padding(part = 'header', padding.left = 3, padding.right = 3, padding.bottom = 1, padding.top = 1) %>%
        padding(part = 'body', padding.left = 2, padding.right = 2, padding.bottom = 1, padding.top = 1) %>%
        bg(i = seq(from = 1, to = nrow(table_extreme), by = 2), bg = "gray95") %>%
        border_inner_h(border = fp_border(style = 'solid', color = 'gray')) %>%
        border_inner_v(border = fp_border(style = 'solid', color = 'gray')) %>%
        border_outer(part = 'all', border = fp_border(color = 'gray', width = 1.5)) 
        
      
    })
    
    
    lp <- layout_properties(mydoc, layout = "twoPlot_withTitles") 
    idx_1 <- which(lp$ph_label == 'Plot Title 1')
    idx_2 <- which(lp$ph_label == 'Plot Title 2')
    mydoc <- add_slide(mydoc, layout = "twoPlot_withTitles", master = "CriteoPowerpointTheme") %>%
      ph_with_text(paste("Most extreme performing Spots by Channel", channel)) 
    if(length(split_extreme) == 2){
      mydoc <- 
        ph_with_fpars_at(
           mydoc, 
           fpars = list(fpar(ftext('Top Performances', shortcuts$fp_bold(font.family = 'Century Gothic', font.size = 14)))), 
           fp_pars = list(fp_par(text.align = 'center')),
           left = lp$offx[idx_1] - lp$cy[idx_1] / 2 + lp$cx[idx_1] / 2, 
           top = lp$offy[idx_1] + lp$cy[idx_1] / 2 - lp$cx[idx_1] / 2, 
           width = lp$cy[idx_1], height = lp$cx[idx_1], rot = 90
        ) %>%
        ph_with_fpars_at(fpars = list(fpar(ftext('Worst Performances', shortcuts$fp_bold(font.family = 'Century Gothic', font.size = 14)))), 
                         fp_pars = list(fp_par(text.align = 'center')),
                         left = lp$offx[idx_2] - lp$cy[idx_2] / 2 + lp$cx[idx_2] / 2, 
                         top = lp$offy[idx_2] + lp$cy[idx_2] / 2 - lp$cx[idx_2] / 2, 
                         width = lp$cy[idx_2], height = lp$cx[idx_2], rot = 90) %>%
        ph_with_flextable(value = top_lower_extreme[[1]], index = which(lp$ph_label == "Plot 1")) %>%
        ph_with_flextable(value = top_lower_extreme[[2]], index = which(lp$ph_label == "Plot 2")) 
    } else {
      if(all(split_extreme[[uplift_col]] > 0)){
        mydoc <- ph_with_fpars_at(
            mydoc, 
            fpars = list(fpar(ftext('Top Performances', shortcuts$fp_bold(font.family = 'Century Gothic', font.size = 14)))), 
            fp_pars = list(fp_par(text.align = 'center')),
            left = lp$offx[idx_1] - lp$cy[idx_1] / 2 + lp$cx[idx_1] / 2, 
            top = lp$offy[idx_1] + lp$cy[idx_1] / 2 - lp$cx[idx_1] / 2, 
            width = lp$cy[idx_1], height = lp$cx[idx_1], rot = 90
          ) %>%
          ph_with_flextable(value = top_lower_extreme[[1]], index = which(lp$ph_label == "Plot 1")) 
      } else {
        mydoc <- ph_with_fpars_at(
            mydoc, 
            fpars = list(fpar(ftext('Worst Performances', shortcuts$fp_bold(font.family = 'Century Gothic', font.size = 14)))), 
            fp_pars = list(fp_par(text.align = 'center')),
            left = lp$offx[idx_1] - lp$cy[idx_1] / 2 + lp$cx[idx_1] / 2, 
            top = lp$offy[idx_1] + lp$cy[idx_1] / 2 - lp$cx[idx_1] / 2, 
            width = lp$cy[idx_1], height = lp$cx[idx_1], rot = 90
          ) %>%
          ph_with_flextable(value = top_lower_extreme[[1]], index = which(lp$ph_label == "Plot 1")) 
      }
    }
    
  }
}
incProgress(1 / inc_nr, detail = "Analysis Uplift of Programs done")



# Budget Analysis  table and plots -----------------------------
if(input$budget_analysis){
  
  # Budget for top 10 channels -----------------------------
  # Loop over years
  plots_budget_per_channel = react_plots_budget_per_channel()
  for(i in 1:length(plots_budget_per_channel)){
    
    lp <- layout_properties(mydoc, layout = 'BudgetChannels')
    mydoc <- add_slide(mydoc, layout = 'BudgetChannels', master = 'CriteoPowerpointTheme') %>%
      ph_with_text("Budget spent per week by top 10 Channels") %>%
      ph_with_gg(value = plots_budget_per_channel[[i]], index = which(lp$ph_label == 'Content Placeholder 4'))
    
  }
  
  # Add plots for specific week range
  if(input$budget_specific){
    
    plot_channel_week <- react_plot_channel_week()
    
    lp <- layout_properties(mydoc, layout = 'BudgetChannels')
    mydoc <- add_slide(mydoc, layout = 'BudgetChannels', master = 'CriteoPowerpointTheme') %>%
      ph_with_text("Budget spent per week by top 10 channels for selected week range") %>%
      ph_with_gg(value = plot_channel_week, index = which(lp$ph_label == 'Content Placeholder 4'))
    
  }
  
  # Top Programs by budget ----------------------------------
  table_budget_per_program = react_table_budget_per_program()
  
  # Set Up Flex Table
  colnames(table_budget_per_program) <- c('Channel', 'Program', 'total', 'number', 'perspot')
  flex_budget <- flextable(table_budget_per_program[1:16]) %>%
    set_header_labels('Channel' = 'Channel', 'Program' = 'Program', 'total' = 'total budget', 
                      'number' = '# spots', 'perspot' = 'budget per spot') %>%
    width(width = c(1.5, 5, 1.5, 1.5, 1.5)) %>%
    fontsize(part = 'header', size = 12) %>%
    bold(part = 'header') %>%
    font(part = 'all', fontname = 'Century Gothic') %>%
    padding(part = 'header', padding.left = 3, padding.right = 3, padding.bottom = 3, padding.top = 3) %>%
    padding(part = 'body', padding.left = 3, padding.right = 3, padding.bottom = 2, padding.top = 2) %>%
    bg(i = seq(from = 1, to = 16, by = 2), bg = "gray95") %>%
    border_inner_h(border = fp_border(style = 'solid', color = 'gray')) %>%
    border_inner_v(border = fp_border(style = 'solid', color = 'gray')) %>%
    border_outer(part = 'all', border = fp_border(color = 'gray', width = 1.5)) 
    
  mydoc <- add_slide(mydoc, layout = 'BudgetChannels', master = 'CriteoPowerpointTheme') %>%
    ph_with_text(paste0("Top programs, ordered by ", input$order_budget_col)) %>%
    ph_with_flextable(value = flex_budget, index = which(lp$ph_label == 'Content Placeholder 4'))
  
  # Budget spent per weekday --------------------------------
  plot_channel_weekday <- react_plot_channel_weekday()
  
  mydoc <- add_slide(mydoc, layout = 'BudgetChannels', master = 'CriteoPowerpointTheme') %>%
    ph_with_text("Budget spent per weekday and channel") %>%
    ph_with_gg(value = plot_channel_weekday, index = which(lp$ph_label == 'Content Placeholder 4'))
  
}
incProgress(1 / inc_nr, detail = "Slides are produced")