#' Function for the budget Analysis
#' 
#' Budget Analysis is optional as not all mediaplans have informations about budget spent per spot
#' Steps: 
#'     1. Prepare Data, filter for top channels by budget, render budget channel list
#'     2. Weekly Analysis: 
#'         2.1 Budget spent per week
#'         2.2 Budget spent per week for selected date range
#'     3. Top Programs by Budget: Calculate programs with most spent budget on
#'     4. Budget spent per weekday and channel
#' 
#' @param input_mediaplan Mediaplan 
#' @param budget_col Column for budget_analyis
#' @param input reactive shiny input
#' @param output reactive shiny output
#' @return 
#' @author Conrad Quandel <c.quandel@@criteo.com>
#' 


budget_col = input$budget_column

# 1. Prepare Data -----------------------------------
budget_data = data.table(react_input_mediaplan())
colnames(budget_data)[grep(budget_col, colnames(budget_data))[1]] <- "Budget"
budget_data$week = lubridate::week(budget_data$Date)
budget_data$Year = lubridate::year(budget_data$Date)

# Use program data to not restrict data on top 10 channels
program_data = budget_data

# Calculate total budget per channel
budget_channel = budget_data[, .(
  sum_budget = sum(Budget)
), by = Channel]
setorderv(budget_channel, "sum_budget", order = -1)

# Filter for top 10 channels by budget 
chosen_channels = budget_channel$Channel[1:10]
budget_data = budget_data[chosen_channels, on = "Channel"]
budget_data = na.omit(budget_data, cols = "Year")

# Split data by year
split_by_year <- split(budget_data, by = "Year")

# Render Table with channels ordered by total budget
output$table_budget_per_channel <- renderDataTable({
  
  budget_channel
  
}, options = list(lengthMenu = c(5, 10, 20, 40)))

insertUI(
  
  selector = '#select_top_channels', 
  ui = numericInput(inputId = "budget_channels", label = "Choose number of ordered top channels for plot", 
                    value = 5, min = 1, max = nrow(budget_channel))

  
)
 
# Aggregate Data over week 
budget_per_channel <- lapply(1:length(split_by_year), function(i){
  budget_per_channel <- split_by_year[[i]][, .(
    sum_budget = sum(Budget)
  ), by = .(week, Channel)]
})
names(budget_per_channel) <- names(split_by_year)

# Select year of analysis 
insertUI(
  
  selector = '#Year', 
  ui = selectInput(inputId = "budget_select_year", label = "Select Year", 
                   choices = names(split_by_year))
  
)


# 2. Weekly Analysis ----------------------------------
# Graph for budget per channel per week
react_plots_budget_per_channel = reactive({
  
  # Loop over years
  plots_per_channel = lapply(1:length(budget_per_channel), function(i){
    
    plot_budget_data = budget_per_channel[[i]]
    
    # Add channels to weeks where they do not exist for plots 
    # Loop over weeks
    for(wk in unique(plot_budget_data$week)){
      
      # select week and not existing channels in that week
      week_budget <- plot_budget_data[week == wk]
      non_channels <- chosen_channels[!chosen_channels %in% week_budget$Channel]
      # if there are not existing channels add channel without budget
      if(length(non_channels) > 0){
        plot_budget_data <- rbind(plot_budget_data, 
                                  data.table(data.frame(week = wk, Channel = non_channels, 
                                                        sum_budget = 0)))
      }
    }
    plot_budget_data$week <- as.numeric(plot_budget_data$week)
    
    # 2.1 Budget spent per week -------------------------------------
    plot_channel_week <- ggplot(data = plot_budget_data, aes(x = week, y = sum_budget, fill = Channel)) + 
      geom_area() + 
      scale_fill_criteo() + 
      ylab("Budget") + xlab("Week") + theme_bw() + 
      ggtitle(paste0("Budget for top channels in Year ", names(budget_per_channel)[i])) + 
      theme(plot.title = element_text(hjust = 0.5, size = 14))
    plot_channel_week
    
  })
  names(plots_per_channel) = names(split_by_year)
  
  return(plots_per_channel)
  
})

# Render plot for selected year 
output$plot_budget_per_channel = renderPlot({
  
  plots_per_channel = react_plots_budget_per_channel()
  plots_per_channel[[input$budget_select_year]] 
  
})

# 2.2 Budget spent per week for selected date range ----------------------------
output$plot_budget_week_range <- renderPlot({
  
  # Filter for chosen year and week range
  plot_budget_data <- budget_per_channel[[input$budget_select_year]]
  plot_budget_data <- plot_budget_data[week >= input$budget_week_range[1] & week <= input$budget_week_range[2]]
  
  # Fill data with channels in weeks where there is no budget spent by that channel
  # Loop over weeks
  for(wk in unique(plot_budget_data$week)){
    
    # Select week data and channels without budget
    week_budget <- plot_budget_data[week == wk]
    non_channels <- chosen_channels[!chosen_channels %in% week_budget$Channel]
    # Add channels without budget with zero budget to data
    if(length(non_channels) > 0){
      plot_budget_data <- rbind(plot_budget_data,
                                data.table(data.frame(week = wk, Channel = non_channels,
                                                      sum_budget = 0)))
    }
    
  }
  plot_budget_data$week <- as.numeric(plot_budget_data$week)
  
  # Plot budget data for selected date range
  plot_channel_week <- ggplot(data = plot_budget_data, aes(x = week, y = sum_budget, fill = Channel)) + 
    geom_area() + 
    scale_fill_criteo() + 
    ylab("Budget") + xlab("Week") + theme_bw() + 
    ggtitle(paste0("Budget for top channels in Year ", input$budget_select_year)) + 
    theme(plot.title = element_text(hjust = 0.5, size = 14))
  
  react_plot_channel_week(plot_channel_week)
  plot_channel_week
  
})


# 3. Top Programs by Budget -----------------------
react_table_budget_per_program = reactive({
  
  # Sum Budget per program per Channel
  budget_per_program <- program_data[, .(
    sum_budget = round(sum(Budget), digit = 0),
    numb_of_spots = .N, 
    budget_per_spot = round(sum(Budget) / .N, digits = 0)
  ), by = .(Channel, Program)]
  colnames(budget_per_program)[3:5] <- c("total budget", "# spots", "budet per spot")
  
  setorderv(budget_per_program, input$order_budget_col, -1)
  
  return(budget_per_program)
  
})


# Render Data Tabel with most spending programs
output$budget_top_programs <- renderDataTable({
  
  react_table_budget_per_program()
  
}, options = list(lengthMenu = c(5, 10, 20, 50)))


# 4. Budget spent per weekday and channel --------------------------
react_table_budget_per_weekday = reactive({
  
  # Calculate total budget per weekday and channel
  budget_per_weekday = program_data[, .(
    sum_budget = sum(Budget)
  ), by = .(weekday, Channel)]
  
  
  # Add channels to weekdays where they do not exist for plots 
  # Loop over weeks
  for(wk in unique(budget_per_weekday$weekday)){
    
    # Select week and channels without budget
    week_budget = budget_per_weekday[weekday == wk]
    non_channels = unique(budget_per_weekday$Channel)[!unique(budget_per_weekday$Channel) %in% week_budget$Channel]
    
    # Add Channels without spent budget with zero budget to data
    if(length(non_channels) > 0){
      budget_per_weekday = rbind(budget_per_weekday, 
                                 data.table(data.frame(weekday = wk, Channel = non_channels, 
                                                       sum_budget = 0)))
    }
    
  }
  budget_per_weekday$weekday_plot = as.numeric(budget_per_weekday$weekday)
  return(budget_per_weekday)
  
})



# Plots for Budget per weekday and channel
output$plot_budget_per_weekday = renderPlot({
  
  selected_channels = budget_channel$Channel[1:input$budget_channels]
  
  budget_per_weekday = react_table_budget_per_weekday()
  budget_per_weekday = budget_per_weekday[selected_channels, on = "Channel"]
  
  # Plot data
  plot_channel_weekday = ggplot(data = budget_per_weekday, aes(x = weekday_plot, y = sum_budget, fill = Channel)) + 
    geom_area() + 
    scale_fill_criteo() + 
    ylab("Budget") + xlab("Weekday") + theme_bw() + 
    ggtitle("Budget spent per Channel per Weekday") + 
    theme(plot.title = element_text(hjust = 0.5, size = 14)) + 
    scale_x_continuous(breaks = unique(budget_per_weekday$weekday_plot), labels = unique(as.character(budget_per_weekday$weekday)))
  react_plot_channel_weekday(plot_channel_weekday)
  plot_channel_weekday
  
})
  