# A Shiny App to analyse the influence of TV campaigns. 

The vision of this project is to implement a shiny app, which analyses a TV Campaign on its impact on the user behaviour online. The shiny app uses a mediaplan and extracted hive data to compair the pre TV and TV time and see an eventual uplift because of TV campaigns. 


## How to start the App

If you run the App the first time, please make sure that the following packages are installed (tested with R 3.4.4): 

#### Criteo R Base: please follow the "How to use CriteoRBase?" on [Confluence](https://confluence.criteois.com/display/AKB/E+-+R+and+Criteo+Packages#) maintained by Central AX

```r
install.packages("shiny")
install.packages("shinydashboard")
install.packages("shinyBS")
install.packages("shinyjs")
install.packages("data.table")
install.packages("ggplot2")
install.packages("CriteoRBase")
install.packages("RJDBC")
install.packages("TTR")
install.packages("ggplot2")
install.packages("xts")
install.packages("zoo")
install.packages("gridExtra")
install.packages("reshape")
install.packages("scales")
install.packages("MASS")
install.packages("dplyr")
install.packages("readr")
install.packages("xlsx")
install.packages("openxlsx")
install.packages("lubridate")
install.packages("tidyr")
install.packages("stringi")
install.packages("stringr")
install.packages("DT")
install.packages("forecast")
install.packages("tools")
install.packages("officer")
install.packages("flextable")
install.packages("rvg")
```

## Run the App from git:
```r
library(shiny)
runUrl("https://gitlab.criteois.com/ax-analytics/TVex/repository/archive.zip", 
        subdir = "TV_App", launch.browser=TRUE)
```

## Project Members: 
Sonja Metzger (AX DE), Conrad Quandel (AX DE)


## Contacts
[Sonja Metzger](mailto:s.metzger@criteo.com?subject=TV_Analysis)

[Conrad Quandel](mailto:c.quandel@criteo.com?subject=TV_Analysis)

