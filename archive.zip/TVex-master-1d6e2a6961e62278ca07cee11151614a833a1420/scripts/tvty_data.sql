use cquandel;
set mapreduce.job.name='AXTool_TVex';
set mapreduce.map.memory.mb=4096;
set mapreduce.reduce.memory.mb=5120;
set hive.cli.print.header = TRUE;
SET startDate = __start_date__;
SET endDate = __end_date__;
SET partner_id = __partner_id__;

select
timestamp,
received_timestamp,
broadcast_timestamp,
tv_tracking_provider,
partner_id,
broadcast_duration_sec,
country,
ad_brand,
spot_name,
tv_channel_name,
prev_program,
next_program,
genre
from
--self_central_eu_t1.tvty_tracking_data
glup.tv_ad_schedule
where day >= ${hiveconf:startDate} and day <= ${hiveconf:endDate} and partner_id = ${hiveconf:partner_id};
