# Welcome to TVex - Git!

This folder contains a R shiny app to analyse the uplift of events a TV spot results in. The usage of the App
is explained in the TV_APP folder. More informations about the analysis can be found on the confluence page of the TVex campaign: [TVex_AX_Confluence](https://confluence.criteois.com/display/TVEX/3.%29+AX)

Also it contains a folder with various scripts: 

* Comparisson_tvty_mediaplan
    + Comparing timestamps of spots provided by TVTY and of manual mediaplan
    + Can be adapted to spotwatch or other providers
    + Usage: Change settings at the beginning of file and run script with ctrl + shift + k (or button Knit)
* tvty_data.sql
    + Get TVTY data from hive glup table
    + Set start and end data as well as partner_id. 

